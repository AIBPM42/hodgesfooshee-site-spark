import React from "react";
import { Toaster } from "sonner";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Index from "./pages/Index";
import { SearchPage } from "./pages/SearchPage";
import { PropertiesPage } from "./pages/PropertiesPage";
import ListingsPage from "./pages/ListingsPage";
import NotFound from "./pages/NotFound";
import Blog from "./components/Blog";
import Footer from "./components/Footer";
import AIPage from "./pages/AIPage";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <Toaster richColors position="top-center" />
    <BrowserRouter>
      <div className="min-h-screen flex flex-col">
        <main className="flex-grow">
          <Routes>
            <Route path="/" element={<Index />} />
            <Route path="/search" element={<SearchPage />} />
            <Route path="/listings" element={<ListingsPage />} />
            <Route path="/properties" element={<ListingsPage />} />
            <Route path="/blog" element={<Blog />} />
            <Route path="/ai" element={<AIPage />} />
            <Route path="/mls" element={<Index />} />
            <Route path="*" element={<NotFound />} />
          </Routes>
        </main>
        <Footer />
      </div>
    </BrowserRouter>
  </QueryClientProvider>
);

export default App;