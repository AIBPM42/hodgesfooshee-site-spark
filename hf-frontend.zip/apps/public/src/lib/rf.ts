const BASE = import.meta.env.VITE_REALTYFEED_API_URL?.replace(/\/+$/,'') || "";
const TOKEN = import.meta.env.VITE_REALTYFEED_API_TOKEN;

// Debug logging for environment variables
console.log('🔧 RF Environment Check:', {
  VITE_REALTYFEED_API_URL: import.meta.env.VITE_REALTYFEED_API_URL,
  VITE_REALTYFEED_API_TOKEN: import.meta.env.VITE_REALTYFEED_API_TOKEN ? '[SET]' : '[MISSING]',
  BASE,
  TOKEN: TOKEN ? '[SET]' : '[MISSING]'
});

export function toQuery(params: Record<string, unknown>): string {
  const q = new URLSearchParams();
  Object.entries(params).forEach(([k, v]) => {
    if (v !== undefined && v !== null && v !== "") q.set(k, String(v));
  });
  return q.toString();
}

export async function rfGet(path: string, params?: Record<string, unknown>) {
  if (!BASE) throw new Error("Missing VITE_REALTYFEED_API_URL");
  const qs = params ? toQuery(params) : "";
  const url = `${BASE}${path}${qs ? `?${qs}` : ""}`;
  
  const headers: Record<string, string> = { 
    "accept": "application/json"
  };
  
  if (TOKEN) {
    headers["x-gateway-token"] = TOKEN;
  }
  
  const res = await fetch(url, { 
    headers,
    cache: "no-store" 
  });
  if (res.status === 401) throw new Error("Unauthorized: RF gateway token expired");
  if (!res.ok) {
    const body = await res.text();
    throw new Error(`Upstream error ${res.status}: ${body.slice(0,500)}`);
  }
  return res.json();
}

export function buildOdataFilter({ q, city, minPrice, maxPrice, beds, baths, type }: {
  q?: string;
  city?: string;
  minPrice?: number | string;
  maxPrice?: number | string;
  beds?: number | string;
  baths?: number | string;
  type?: string;
}): string {
  const filters: string[] = [];
  
  // Free text search across multiple fields
  if (q && q.trim()) {
    const searchText = q.trim().replace(/'/g, "''");
    const textFilters = [
      `contains(UnparsedAddress, '${searchText}')`,
      `contains(City, '${searchText}')`,
      `contains(StateOrProvince, '${searchText}')`,
      `contains(PostalCode, '${searchText}')`,
      `contains(ListingId, '${searchText}')`
    ];
    filters.push(`(${textFilters.join(' or ')})`);
  }
  
  if (city && city !== 'all') {
    // Handle numeric zip codes vs city names
    if (/^\d{5}$/.test(city)) {
      filters.push(`PostalCode eq '${city.replace(/'/g, "''")}'`);
    } else {
      filters.push(`contains(City, '${city.replace(/'/g, "''")}')`);
    }
  }
  
  if (minPrice && Number(minPrice) > 0) {
    filters.push(`ListPrice ge ${Number(minPrice)}`);
  }
  
  if (maxPrice && Number(maxPrice) > 0) {
    filters.push(`ListPrice le ${Number(maxPrice)}`);
  }
  
  if (beds && beds !== 'any' && Number(beds) > 0) {
    filters.push(`BedroomsTotal ge ${Number(beds)}`);
  }
  
  if (baths && baths !== 'any' && Number(baths) > 0) {
    filters.push(`BathroomsTotalInteger ge ${Number(baths)}`);
  }
  
  if (type && type !== 'all') {
    filters.push(`PropertyType eq '${type.replace(/'/g, "''")}'`);
  }
  
  return filters.join(' and ');
}

export type RfListParams = Record<string,string|number|undefined>;

export async function rfListings(params: RfListParams) {
  return rfGet('/Property', params);
}

export async function health() {
  try {
    await rfGet('/Property', { $top: 1 });
    return true;
  } catch (error) {
    console.warn('RF API health check failed:', error);
    return false;
  }
}

// Console warning if API URL is missing
if (!BASE) console.warn("VITE_REALTYFEED_API_URL is missing. Set it in your frontend env.");