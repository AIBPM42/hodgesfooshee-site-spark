/**
 * Minimal className combiner that avoids extra deps.
 * Accepts strings/false/null/undefined and joins truthy ones.
 */
export function cn(...classes: Array<string | false | null | undefined>) {
  return classes.filter(Boolean).join(" ");
}