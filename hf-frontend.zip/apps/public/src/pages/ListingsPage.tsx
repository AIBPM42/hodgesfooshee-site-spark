import { useMemo, useState } from "react";
import { useSearchParams, Link } from "react-router-dom";
import { usePropertySearch, SearchFilters } from "../hooks/usePropertySearch";
import Navigation from "../components/Navigation";
import { ArrowLeft, MapPin, Bed, Bath, Home, Activity, X, RefreshCw } from 'lucide-react';

const PREMIUM_UI = import.meta.env.VITE_PREMIUM_LISTINGS_UI === 'true';

export default function ListingsPage() {
  const [sp, setSp] = useSearchParams();

  const $top = Number(sp.get("$top") || 24);
  const $skip = Number(sp.get("$skip") || 0);

  const searchParams = useMemo(() => ({
    q: sp.get("q") || undefined,
    city: sp.get("city") || undefined,
    minPrice: sp.get("minPrice") || undefined,
    maxPrice: sp.get("maxPrice") || undefined,
    beds: sp.get("beds") || undefined,
    baths: sp.get("baths") || undefined,
    property_type: sp.get("property_type") || undefined,
  }), [sp]);

  // Convert URL parameters to SearchFilters format
  const searchFilters: SearchFilters = useMemo(() => ({
    search_query: searchParams.q,
    filter_city: searchParams.city,
    min_price: searchParams.minPrice ? Number(searchParams.minPrice) : undefined,
    max_price: searchParams.maxPrice ? Number(searchParams.maxPrice) : undefined,
    min_beds: searchParams.beds ? Number(searchParams.beds) : undefined,
    min_baths: searchParams.baths ? Number(searchParams.baths) : undefined,
    sort_by: 'price_desc',
    page_limit: $top,
    page_offset: $skip
  }), [searchParams, $top, $skip]);

  // Use the new PropertySearch hook
  const { data: listings, isLoading: loading, error } = usePropertySearch(searchFilters);
  
  const data = listings ? { 
    value: listings, 
    '@odata.count': listings[0]?.total_count || listings.length 
  } : null;
  const err = error?.message;

  function page(next:boolean) {
    const n = Math.max(0, $skip + (next ? $top : -$top));
    sp.set("$skip", String(n)); setSp(sp, { replace:false });
    scrollToTop();
  }

  const getActiveFilters = () => {
    const filters = [];
    if (searchParams.q) filters.push({ key: 'q', label: `"${searchParams.q}"`, value: searchParams.q });
    if (searchParams.city && searchParams.city !== 'all') filters.push({ key: 'city', label: searchParams.city, value: searchParams.city });
    if (searchParams.minPrice) filters.push({ key: 'minPrice', label: `Min $${Number(searchParams.minPrice).toLocaleString()}`, value: searchParams.minPrice });
    if (searchParams.maxPrice) filters.push({ key: 'maxPrice', label: `Max $${Number(searchParams.maxPrice).toLocaleString()}`, value: searchParams.maxPrice });
    if (searchParams.beds && searchParams.beds !== 'any') filters.push({ key: 'beds', label: `${searchParams.beds}+ beds`, value: searchParams.beds });
    if (searchParams.baths && searchParams.baths !== 'any') filters.push({ key: 'baths', label: `${searchParams.baths}+ baths`, value: searchParams.baths });
    if (searchParams.property_type && searchParams.property_type !== 'all') filters.push({ key: 'property_type', label: searchParams.property_type, value: searchParams.property_type });
    return filters;
  };

  const removeFilter = (filterKey: string) => {
    const newSp = new URLSearchParams(sp);
    newSp.delete(filterKey);
    newSp.delete("$skip"); // Reset pagination when filters change
    setSp(newSp, { replace: false });
  };

  const clearAllFilters = () => {
    setSp(new URLSearchParams({ $top: String($top) }), { replace: false });
  };

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // API health based on hook state
  const apiHealth = loading ? 'unknown' : (err ? 'unhealthy' : 'healthy');

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900">
      <Navigation />
      
      {/* Premium Background */}
      <div className="fixed inset-0 bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 -z-10" />
      <div className="fixed inset-0 bg-[url('data:image/svg+xml,%3csvg%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%20viewBox%3D%220%200%2032%2032%22%20width%3D%2232%22%20height%3D%2232%22%20fill%3D%22none%22%20stroke%3D%22rgb(148%20163%20184%20/%200.05)%22%3e%3cpath%20d%3D%22m0%20.5%2032%2032M0%2032%2032%20.5%22/%3e%3c/svg%3e')] -z-10" />
      
      {/* API Health Indicator */}
      <div className="fixed top-20 right-4 z-50">
        <div className="glass-card px-4 py-2 flex items-center gap-2">
          <div className={`w-2 h-2 rounded-full animate-pulse ${
            apiHealth === 'healthy' ? 'bg-emerald-400' : 
            apiHealth === 'unhealthy' ? 'bg-red-400' : 'bg-amber-400'
          }`}></div>
          <span className="text-white/90 text-sm font-medium">
            {apiHealth === 'healthy' ? 'MLS Connected' : 
             apiHealth === 'unhealthy' ? 'MLS Offline' : 'Connecting...'}
          </span>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8 pt-24">
        {/* Header */}
        <div className="flex items-center gap-4 mb-6">
          <Link 
            to="/" 
            className="flex items-center gap-2 text-white/60 hover:text-white transition-colors"
          >
            <ArrowLeft className="w-4 h-4" />
            Back to Search
          </Link>
        </div>

        <div className="flex items-start justify-between mb-6">
          <div>
            <h1 className="text-3xl font-bold text-white mb-2">Search Results</h1>
            {data && (
            <div className="bg-accent/20 text-accent px-3 py-1 rounded-full text-sm inline-flex items-center gap-1" role="status" aria-live="polite">
                <Activity className="w-3 h-3" />
                {data['@odata.count'] || data.value?.length || 0} properties found
              </div>
            )}
          </div>
        </div>

        {/* Premium Active Filters */}
        {getActiveFilters().length > 0 && (
          <div className="glass-card p-4 mb-8 sticky top-32 z-40 animate-fade-in animation-delay-300">
            <div className="flex flex-wrap items-center gap-3">
              <span className="text-white/80 text-sm font-medium flex items-center gap-2">
                <Activity className="w-4 h-4" />
                Active Filters:
              </span>
              {getActiveFilters().map((filter) => (
                <button
                  key={filter.key}
                  onClick={() => removeFilter(filter.key)}
                  className="bg-gradient-to-r from-accent/20 to-accent/10 hover:from-accent/30 hover:to-accent/20 border border-accent/30 text-accent-foreground px-4 py-2 rounded-full text-sm flex items-center gap-2 transition-all duration-300 hover:scale-105 backdrop-blur-sm"
                >
                  <span className="font-medium">{filter.label}</span>
                  <X className="w-4 h-4" />
                </button>
              ))}
              <button
                onClick={clearAllFilters}
                className="bg-gradient-to-r from-red-500/20 to-red-600/10 hover:from-red-500/30 hover:to-red-600/20 border border-red-400/30 text-red-300 px-4 py-2 rounded-full text-sm transition-all duration-300 hover:scale-105 backdrop-blur-sm font-medium ml-2"
              >
                Clear All
              </button>
            </div>
          </div>
        )}

        {/* Error Banner */}
        {err && (
          <div className="glass-card p-6 mb-8 border-l-4 border-red-400 bg-gradient-to-r from-red-500/10 to-transparent">
            <div className="flex items-start gap-4">
              <div className="w-8 h-8 rounded-full bg-red-400/20 flex items-center justify-center flex-shrink-0">
                <Activity className="w-4 h-4 text-red-400" />
              </div>
              <div className="flex-1">
                <h3 className="text-red-300 font-semibold mb-2">Connection Issue</h3>
                <p className="text-red-200/80 text-sm mb-4 leading-relaxed">
                  Unable to connect to the MLS service. This could be a network issue or the service might be temporarily unavailable.
                </p>
              </div>
            </div>
          </div>
        )}

        {/* Premium Loading State */}
        {loading && (
          <div className="space-y-8">
            <div className="glass-card p-8 text-center">
              <div className="flex items-center justify-center gap-4 text-white/80 mb-4">
                <RefreshCw className="w-6 h-6 animate-spin text-accent" />
                <span className="text-lg font-medium">Searching Premium Listings...</span>
              </div>
              <div className="w-full bg-white/10 rounded-full h-2 overflow-hidden">
                <div className="bg-gradient-to-r from-accent to-accent/60 h-full rounded-full animate-pulse" style={{width: '60%'}}></div>
              </div>
            </div>
            
            {/* Premium Loading Skeletons */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {Array.from({ length: 8 }).map((_, i) => (
                <div key={i} className="glass-card overflow-hidden animate-pulse">
                  <div className="h-56 bg-gradient-to-br from-white/10 to-white/5 relative">
                    <div className="absolute inset-0 bg-gradient-to-t from-black/30 to-transparent"></div>
                    <div className="absolute top-4 right-4 w-16 h-6 bg-white/20 rounded-full"></div>
                  </div>
                  <div className="p-6 space-y-4">
                    <div className="h-7 bg-gradient-to-r from-white/20 to-white/10 rounded w-3/4"></div>
                    <div className="flex gap-4">
                      <div className="h-5 bg-white/15 rounded w-16"></div>
                      <div className="h-5 bg-white/15 rounded w-16"></div>
                      <div className="h-5 bg-white/15 rounded w-20"></div>
                    </div>
                    <div className="h-5 bg-white/10 rounded w-full"></div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Premium Error State - No results or connection error */}
        {err && !loading && (
          <div className="glass-card p-8 border-l-4 border-red-400 bg-gradient-to-r from-red-500/10 to-transparent">
            <div className="flex items-start gap-4">
              <div className="w-10 h-10 rounded-full bg-red-400/20 flex items-center justify-center flex-shrink-0">
                <Activity className="w-5 h-5 text-red-400" />
              </div>
              <div className="flex-1">
                <h3 className="text-red-300 font-semibold text-lg mb-3">Unable to Load Properties</h3>
                <div className="bg-black/20 border border-red-400/20 rounded-lg p-4 mb-4">
                  <pre className="text-red-200/80 text-sm whitespace-pre-wrap leading-relaxed">{err}</pre>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Premium Results Grid */}
        {!loading && !err && data && (
          <>
            {Array.isArray(data?.value) && data.value.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6 mb-8 animate-fade-in animation-delay-600">
                {data.value.map((listing: any, i: number) => (
                  <div key={i} className="glass-card overflow-hidden group hover:scale-105 transition-all duration-500 hover:shadow-2xl">
                    {/* Premium Property Image */}
                    <div className="h-56 bg-gradient-to-br from-slate-600 to-slate-800 relative overflow-hidden">
                      <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-black/20"></div>
                      <div className="absolute inset-0 flex items-center justify-center">
                        <Home className="w-16 h-16 text-white/20 group-hover:text-white/30 transition-colors duration-300" />
                      </div>
                      
                      {/* Status Badge */}
                      <div className="absolute top-4 right-4">
                        <div className="bg-emerald-500/90 backdrop-blur-sm px-3 py-1 rounded-full text-white text-xs font-semibold">
                          Active
                        </div>
                      </div>
                      
                       {/* Price Overlay */}
                       <div className="absolute bottom-4 left-4">
                         <div className="text-2xl font-bold text-white drop-shadow-lg">
                           {listing.price ? `$${Number(listing.price).toLocaleString()}` : "Price Available"}
                         </div>
                       </div>
                     </div>
                     
                     {/* Premium Property Details */}
                     <div className="p-6">
                       <div className="flex items-center gap-6 text-white/80 text-sm mb-4">
                         <div className="flex items-center gap-2">
                           <Bed className="w-4 h-4 text-accent" />
                           <span className="font-medium">{listing.beds ?? "—"} bd</span>
                         </div>
                         <div className="flex items-center gap-2">
                           <Bath className="w-4 h-4 text-accent" />
                           <span className="font-medium">{listing.baths ?? "—"} ba</span>
                         </div>
                         <div className="text-white/60">
                           {listing.sqft ? `${Number(listing.sqft).toLocaleString()} sqft` : "—"}
                         </div>
                       </div>
                       
                       <div className="flex items-start gap-2 text-white/70">
                         <MapPin className="w-4 h-4 mt-1 flex-shrink-0 text-accent" />
                         <span className="text-sm leading-relaxed">
                           {listing.address || "Address Available"}
                         </span>
                       </div>
                       
                       {/* Property Type Badge */}
                       {listing.property_type && (
                         <div className="mt-4 pt-4 border-t border-white/10">
                           <span className="bg-white/10 text-white/80 px-3 py-1 rounded-full text-xs font-medium">
                             {listing.property_type}
                           </span>
                         </div>
                       )}
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="glass-card p-12 text-center" role="status" aria-live="polite">
                <div className="w-24 h-24 rounded-full bg-white/5 flex items-center justify-center mx-auto mb-6">
                  <Home className="w-12 h-12 text-white/30" />
                </div>
                <h3 className="text-2xl font-semibold text-white/80 mb-3">No Properties Match Your Search</h3>
                <p className="text-white/60 mb-8 max-w-md mx-auto leading-relaxed">
                  We couldn't find any properties matching your current criteria. Try adjusting your filters or start a new search.
                </p>
                <div className="flex gap-4 justify-center flex-wrap">
                  <button 
                    onClick={clearAllFilters}
                    className="bg-gradient-to-r from-accent to-accent/80 hover:from-accent/90 hover:to-accent/70 text-white px-8 py-3 rounded-lg transition-all duration-300 hover:scale-105 font-medium shadow-lg"
                  >
                    Reset All Filters
                  </button>
                  <Link 
                    to="/" 
                    className="inline-block bg-gradient-to-r from-white/10 to-white/5 hover:from-white/20 hover:to-white/10 text-white px-8 py-3 rounded-lg transition-all duration-300 hover:scale-105 font-medium border border-white/20"
                  >
                    Start New Search
                  </Link>
                </div>
              </div>
            )}

           {/* Premium Pagination */}
            {data?.value?.length > 0 && (
              <div className="glass-card p-6 sticky bottom-4 z-30">
                <div className="flex items-center justify-between">
                  <button 
                    onClick={() => page(false)} 
                    disabled={$skip <= 0}
                    className="px-8 py-3 bg-gradient-to-r from-white/10 to-white/5 hover:from-white/20 hover:to-white/10 disabled:opacity-40 disabled:cursor-not-allowed text-white rounded-lg transition-all duration-300 hover:scale-105 font-medium border border-white/20 flex items-center gap-2"
                  >
                    <ArrowLeft className="w-4 h-4" />
                    Previous
                  </button>
                  
                  <div className="text-center">
                    <div className="text-white/90 font-medium mb-1">
                      Showing {$skip + 1} - {Math.min($skip + $top, ($skip + data.value.length))}
                    </div>
                    {data['@odata.count'] && (
                      <div className="text-white/60 text-sm">
                        of {data['@odata.count'].toLocaleString()} total properties
                      </div>
                    )}
                  </div>
                  
                  <button 
                    onClick={() => page(true)}
                    disabled={!data.value || data.value.length < $top}
                    className="px-8 py-3 bg-gradient-to-r from-accent to-accent/80 hover:from-accent/90 hover:to-accent/70 disabled:opacity-40 disabled:cursor-not-allowed text-white rounded-lg transition-all duration-300 hover:scale-105 font-medium shadow-lg flex items-center gap-2"
                  >
                    Next
                    <ArrowLeft className="w-4 h-4 rotate-180" />
                  </button>
                </div>
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
}