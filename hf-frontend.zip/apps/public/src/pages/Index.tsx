import React from 'react';
import Navigation from '../components/Navigation';
import HeroSection from '../components/HeroSection';
import BlockRenderer from '../components/BlockRenderer';

export default function Index() {
  return (
    <div className="min-h-screen">
      <Navigation />
      <main>
        {/* Premium hero section with beautiful background */}
        <HeroSection />
        {/* Intentionally not showing listings on home page */}
        <BlockRenderer blocks={[]} />
      </main>
    </div>
  );
}