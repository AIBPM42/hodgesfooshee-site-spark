import React, { useState } from 'react';

const tabs = ["Zip Insights", "Pricing", "Commute"];

const AIPage: React.FC = () => {
  const [active, setActive] = useState(0);
  
  return (
    <main className="mx-auto max-w-6xl px-4 py-10">
      <h1 className="text-3xl font-bold mb-6">AI Intelligence</h1>
      <div className="flex gap-3 border-b border-white/10 mb-6">
        {tabs.map((t, i) => (
          <button
            key={t}
            onClick={() => setActive(i)}
            className={`px-3 py-2 rounded-t ${
              i === active ? "bg-white/10" : "hover:bg-white/5"
            }`}
          >
            {t}
          </button>
        ))}
      </div>
      <section className="bg-white/5 rounded-xl p-4">
        <p className="opacity-80">
          {tabs[active]} — content placeholder. (UI library removed to fix build.)
        </p>
      </section>
    </main>
  );
};

export default AIPage;