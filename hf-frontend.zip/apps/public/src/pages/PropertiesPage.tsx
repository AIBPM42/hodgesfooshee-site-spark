import React, { useState, useMemo } from "react";
import { useSearchParams } from "react-router-dom";
import Navigation from "@/components/Navigation";
import { PropertiesHero } from "@/components/PropertiesHero";
import { PropertyResultCard } from "@/components/PropertyResultCard";
import { usePropertySearch } from "@/hooks/usePropertySearch";
import { Button } from "@/components/ui/button";
import { ChevronLeft, ChevronRight, Loader2 } from "lucide-react";

export const PropertiesPage = () => {
  const [searchParams] = useSearchParams();
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 12;

  // Parse search parameters
  const filters = useMemo(() => ({
    search_query: searchParams.get('q') || '',
    filter_city: searchParams.get('city') || '',
    min_price: searchParams.get('min_price') ? parseInt(searchParams.get('min_price')!) : undefined,
    max_price: searchParams.get('max_price') ? parseInt(searchParams.get('max_price')!) : undefined,
    min_beds: searchParams.get('beds') ? parseInt(searchParams.get('beds')!) : undefined,
    min_baths: searchParams.get('baths') ? parseFloat(searchParams.get('baths')!) : undefined,
    sort_by: 'price_desc' as const,
    page_limit: Math.min(parseInt(searchParams.get('limit') || '20'), 50),
    page_offset: (currentPage - 1) * itemsPerPage
  }), [searchParams, currentPage, itemsPerPage]);

  const { data: properties = [], isLoading, error } = usePropertySearch(filters);

  const totalResults = properties.length > 0 ? properties[0]?.total_count || 0 : 0;
  const totalPages = Math.ceil(totalResults / itemsPerPage);

  const hasSearchQuery = !!(
    filters.search_query ||
    filters.filter_city ||
    filters.min_price ||
    filters.max_price ||
    filters.min_beds ||
    filters.min_baths
  );

  const formatSearchSummary = () => {
    const parts = [];
    if (filters.search_query) parts.push(`"${filters.search_query}"`);
    if (filters.filter_city) parts.push(`in ${filters.filter_city}`);
    if (filters.min_beds) parts.push(`${filters.min_beds}+ beds`);
    if (filters.min_baths) parts.push(`${filters.min_baths}+ baths`);
    if (filters.min_price || filters.max_price) {
      const priceRange = [];
      if (filters.min_price) priceRange.push(`$${filters.min_price.toLocaleString()}+`);
      if (filters.max_price) priceRange.push(`under $${filters.max_price.toLocaleString()}`);
      parts.push(priceRange.join(' - '));
    }
    return parts.join(', ');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary/5 via-background to-secondary/5">
      <Navigation />
      
      {/* Properties Hero Section */}
      <PropertiesHero />
      
      <div className="container mx-auto px-4 py-8">

        {/* Results Header */}
        <div className="mb-6">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
            <div>
              <h1 className="text-2xl font-bold text-foreground">
                {hasSearchQuery ? 'Search Results' : 'All Properties'}
              </h1>
              {hasSearchQuery && (
                <p className="text-sm text-muted-foreground mt-1">
                  {formatSearchSummary()}
                </p>
              )}
              <p className="text-sm text-muted-foreground mt-1">
                {isLoading ? 'Loading...' : `${totalResults.toLocaleString()} properties found`}
              </p>
            </div>
            
            {totalPages > 1 && (
              <div className="text-sm text-muted-foreground">
                Page {currentPage} of {totalPages}
              </div>
            )}
          </div>
        </div>

        {/* Loading State */}
        {isLoading && (
          <div className="flex justify-center items-center py-12">
            <Loader2 className="w-8 h-8 animate-spin text-primary" />
          </div>
        )}

        {/* Error State */}
        {error && (
          <div className="text-center py-12">
            <p className="text-destructive">Error loading properties. Please try again.</p>
          </div>
        )}

        {/* No Results */}
        {!isLoading && !error && properties.length === 0 && (
          <div className="text-center py-12">
            <h3 className="text-lg font-semibold text-foreground mb-2">No properties found</h3>
            <p className="text-muted-foreground">
              Try adjusting your search criteria or browse all available properties.
            </p>
          </div>
        )}

        {/* Properties Grid */}
        {!isLoading && properties.length > 0 && (
          <>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
              {properties.map((property) => (
                <PropertyResultCard
                  key={property.id}
                  property={property}
                />
              ))}
            </div>

            {/* Pagination */}
            {totalPages > 1 && (
              <div className="flex justify-center items-center space-x-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setCurrentPage(prev => Math.max(1, prev - 1))}
                  disabled={currentPage === 1}
                >
                  <ChevronLeft className="w-4 h-4 mr-1" />
                  Previous
                </Button>
                
                <div className="flex space-x-1">
                  {Array.from({ length: Math.min(5, totalPages) }, (_, i) => {
                    let pageNum;
                    if (totalPages <= 5) {
                      pageNum = i + 1;
                    } else if (currentPage <= 3) {
                      pageNum = i + 1;
                    } else if (currentPage >= totalPages - 2) {
                      pageNum = totalPages - 4 + i;
                    } else {
                      pageNum = currentPage - 2 + i;
                    }
                    
                    return (
                      <Button
                        key={pageNum}
                        variant={currentPage === pageNum ? "default" : "outline"}
                        size="sm"
                        onClick={() => setCurrentPage(pageNum)}
                        className="w-8 h-8"
                      >
                        {pageNum}
                      </Button>
                    );
                  })}
                </div>
                
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setCurrentPage(prev => Math.min(totalPages, prev + 1))}
                  disabled={currentPage === totalPages}
                >
                  Next
                  <ChevronRight className="w-4 h-4 ml-1" />
                </Button>
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
};