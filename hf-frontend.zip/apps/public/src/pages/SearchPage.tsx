import { useEffect, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import PropertyCard from '../components/PropertyCard';
import { SearchFilters } from '../components/SearchFilters';
// Hook removed - using simple state management instead
import Navigation from '../components/Navigation';

export const SearchPage = () => {
  const [searchParams] = useSearchParams();
  const [currentPage, setCurrentPage] = useState(1);
  const pageSize = 20;

  // Mock properties for demonstration
  const properties = [
    { id: 1, ListPrice: 525000, BedroomsTotal: 3, BathroomsTotalInteger: 2, LivingArea: 2100, UnparsedAddress: "123 Music Row, Nashville, TN" },
    { id: 2, ListPrice: 675000, BedroomsTotal: 4, BathroomsTotalInteger: 3, LivingArea: 2800, UnparsedAddress: "456 Belle Meade Blvd, Nashville, TN" },
    { id: 3, ListPrice: 450000, BedroomsTotal: 3, BathroomsTotalInteger: 2, LivingArea: 1850, UnparsedAddress: "789 East Nashville Ave, Nashville, TN" },
  ];

  const totalCount = properties.length;
  const totalPages = Math.ceil(totalCount / pageSize);
  const isLoading = false;
  const error = null;

  const handlePageChange = (page: number) => {
    const newSearchParams = new URLSearchParams(searchParams.toString());
    newSearchParams.set('page', page.toString());
    window.history.pushState({}, '', `?${newSearchParams.toString()}`);
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-background via-background/95 to-background">
      <Navigation />
      
      <main className="container mx-auto px-4 py-8">
        {/* Page Header */}
        <div className="mb-8">
          <h1 className="text-4xl font-bold mb-2 bg-gradient-to-r from-primary to-primary/70 bg-clip-text text-transparent">
            Property Search
          </h1>
          <p className="text-muted-foreground text-lg">
            {totalCount > 0 ? `${totalCount} properties found` : 'Search Nashville\'s finest properties'}
          </p>
        </div>

        {/* Sticky Filters */}
        <div className="sticky top-0 z-10 mb-8">
          <SearchFilters />
        </div>

        {/* Results */}
        {isLoading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {Array.from({ length: 12 }).map((_, index) => (
              <div key={index} className="bg-background/40 backdrop-blur-md rounded-lg h-96 animate-pulse" />
            ))}
          </div>
        ) : error ? (
          <div className="text-center py-12">
            <p className="text-destructive text-lg">Error loading properties. Please try again.</p>
          </div>
        ) : !properties?.length ? (
          <div className="text-center py-12">
            <p className="text-muted-foreground text-lg">No properties found matching your criteria.</p>
            <p className="text-muted-foreground">Try adjusting your search filters.</p>
          </div>
        ) : (
          <>
            {/* Property Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6 mb-8">
              {properties.map((property) => (
                <PropertyCard key={property.id} property={property} />
              ))}
            </div>

            {/* Pagination */}
            {totalPages > 1 && (
              <div className="flex justify-center items-center gap-2 py-8">
                <button
                  onClick={() => handlePageChange(currentPage - 1)}
                  disabled={currentPage <= 1}
                  className="px-4 py-2 rounded-md bg-background/60 backdrop-blur-sm border border-white/20 text-foreground disabled:opacity-50 disabled:cursor-not-allowed hover:bg-background/80 transition-colors"
                >
                  Previous
                </button>
                
                {Array.from({ length: Math.min(5, totalPages) }, (_, i) => {
                  const pageNum = i + Math.max(1, currentPage - 2);
                  if (pageNum > totalPages) return null;
                  
                  return (
                    <button
                      key={pageNum}
                      onClick={() => handlePageChange(pageNum)}
                      className={`px-4 py-2 rounded-md border transition-colors ${
                        pageNum === currentPage
                          ? 'bg-primary text-primary-foreground border-primary'
                          : 'bg-background/60 backdrop-blur-sm border-white/20 text-foreground hover:bg-background/80'
                      }`}
                    >
                      {pageNum}
                    </button>
                  );
                })}
                
                <button
                  onClick={() => handlePageChange(currentPage + 1)}
                  disabled={currentPage >= totalPages}
                  className="px-4 py-2 rounded-md bg-background/60 backdrop-blur-sm border border-white/20 text-foreground disabled:opacity-50 disabled:cursor-not-allowed hover:bg-background/80 transition-colors"
                >
                  Next
                </button>
              </div>
            )}
          </>
        )}
      </main>
    </div>
  );
};