import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';

export interface ZipCodeSuggestion {
  ZipCode: string;
  City: string;
  State: string;
  County: string;
  DisplayText: string;
}

export interface ZipCodeDetails {
  ZipCode: string;
  City: string;
  State: string;
  County: string;
  MedianPrice: number;
  AveragePrice: number;
  DaysOnMarket: number;
  PriceChange: number;
  ActiveListings: number;
  SoldListings: number;
  SchoolRating: number;
}

export const useZipCodeAutocomplete = (query: string) => {
  return useQuery({
    queryKey: ['zip-autocomplete', query],
    queryFn: async (): Promise<ZipCodeSuggestion[]> => {
      console.log('useZipCodeAutocomplete called with query:', query);
      
      if (!query || query.length < 2) {
        console.log('Query too short, returning empty array');
        return [];
      }
      
      try {
        const { data, error } = await supabase.functions.invoke('zip-code-intelligence', {
          body: {
            action: 'autocomplete',
            query: query
          }
        });

        console.log('Autocomplete API response:', { data, error });

        if (error) {
          console.error('Zip code autocomplete error:', error);
          return [];
        }

        // Transform RESO data into unique city/zip combinations
        const properties = data?.value || [];
        console.log('Properties from API:', properties.length);
        
        const locationMap = new Map<string, ZipCodeSuggestion>();
        
        properties.forEach((prop: any) => {
          const city = prop.City;
          const zipCode = prop.PostalCode;
          const county = prop.CountyOrParish;
          const state = prop.StateOrProvince || 'TN';
          
          if (city && zipCode) {
            const key = `${city}-${zipCode}`;
            if (!locationMap.has(key)) {
              locationMap.set(key, {
                ZipCode: zipCode,
                City: city,
                State: state,
                County: county || '',
                DisplayText: `${city}, ${state} ${zipCode}`
              });
            }
          }
        });

        const results = Array.from(locationMap.values()).slice(0, 8);
        console.log('Final autocomplete results:', results);
        return results;
      } catch (error) {
        console.error('Autocomplete function error:', error);
        return [];
      }
    },
    enabled: query.length >= 2,
    staleTime: 1000 * 60 * 5, // 5 minutes
    retry: false, // Don't retry failed requests for debugging
  });
};

export const useZipCodeDetails = (zipCode: string) => {
  return useQuery({
    queryKey: ['zip-details', zipCode],
    queryFn: async (): Promise<ZipCodeDetails | null> => {
      console.log('useZipCodeDetails called with zipCode:', zipCode);
      
      if (!zipCode) {
        console.log('No zipCode provided');
        return null;
      }
      
      try {
        const { data, error } = await supabase.functions.invoke('zip-code-intelligence', {
          body: {
            action: 'details',
            zipCode: zipCode
          }
        });

        console.log('Details API response for', zipCode, ':', { data, error });

        if (error) {
          console.error('Zip code details error:', error);
          return null;
        }

        const properties = data?.value || [];
        console.log('Properties for details:', properties.length);
        
        if (properties.length === 0) return null;

        // Calculate market statistics from the properties
        const prices = properties.map((p: any) => parseInt(p.ListPrice) || 0).filter((p: number) => p > 0);
        const bedCounts = properties.map((p: any) => parseInt(p.BedroomsTotal) || 0);
        const bathCounts = properties.map((p: any) => parseInt(p.BathroomsTotalInteger) || 0);
        const sqftValues = properties.map((p: any) => parseInt(p.LivingArea) || 0).filter((s: number) => s > 0);

        if (prices.length === 0) return null;

        // Calculate statistics
        prices.sort((a, b) => a - b);
        const medianPrice = prices[Math.floor(prices.length / 2)];
        const averagePrice = Math.round(prices.reduce((sum, price) => sum + price, 0) / prices.length);
        
        // Use the first property for location info
        const firstProp = properties[0];
        
        const result = {
          ZipCode: zipCode,
          City: firstProp.City || '',
          State: firstProp.StateOrProvince || 'TN',
          County: firstProp.CountyOrParish || '',
          MedianPrice: medianPrice,
          AveragePrice: averagePrice,
          DaysOnMarket: 25, // Default estimate since we don't have this data
          PriceChange: Math.floor(Math.random() * 10) - 5, // Random for demo
          ActiveListings: properties.length,
          SoldListings: 0, // We only get active listings
          SchoolRating: 8 // Default rating
        };
        
        console.log('Final details result for', zipCode, ':', result);
        return result;
      } catch (error) {
        console.error('Details function error for', zipCode, ':', error);
        return null;
      }
    },
    enabled: !!zipCode,
    staleTime: 1000 * 60 * 10, // 10 minutes
    retry: false, // Don't retry failed requests for debugging
  });
};

export const useNearbyZipCodes = (zipCode: string) => {
  return useQuery({
    queryKey: ['nearby-zips', zipCode],
    queryFn: async (): Promise<ZipCodeDetails[]> => {
      if (!zipCode) return [];
      
      const { data, error } = await supabase.functions.invoke('zip-code-intelligence', {
        body: {
          action: 'nearby',
          zipCode: zipCode
        }
      });

      if (error) {
        console.error('Nearby zip codes error:', error);
        return [];
      }

      return data?.value || [];
    },
    enabled: !!zipCode,
    staleTime: 1000 * 60 * 15, // 15 minutes
  });
};