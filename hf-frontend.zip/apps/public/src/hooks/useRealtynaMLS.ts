import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { SearchFilters, PropertyListing } from './usePropertySearch';

export const useRealtynaMLS = (filters: SearchFilters) => {
  return useQuery({
    queryKey: ['realtyna-mls-search', filters],
    queryFn: async (): Promise<PropertyListing[]> => {
      console.log('Calling Realtyna MLS with filters:', filters);
      
      const { data, error } = await supabase.functions.invoke('realtyna-mls-search', {
        body: {
          search_query: filters.search_query || '',
          filter_city: filters.filter_city || '',
          min_price: filters.min_price || 0,
          max_price: filters.max_price || 999999999,
          min_beds: filters.min_beds || 0,
          max_beds: filters.max_beds || 99,
          min_baths: filters.min_baths || 0,
          max_baths: filters.max_baths || 99,
          sort_by: filters.sort_by || 'price_desc',
          page_limit: filters.page_limit || 20,
          page_offset: filters.page_offset || 0
        },
        headers: {
          'x-gateway-token': import.meta.env.VITE_REALTYFEED_API_TOKEN
        }
      });

      if (error) {
        console.error('Error calling Realtyna MLS function:', error);
        throw error;
      }

      console.log('Received data from Realtyna MLS:', { 
        count: data?.length || 0,
        firstItem: data?.[0] || null 
      });

      return data || [];
    },
    enabled: true,
    staleTime: 1000 * 60 * 2, // 2 minutes (more frequent for live MLS data)
    retry: 2,
  });
};