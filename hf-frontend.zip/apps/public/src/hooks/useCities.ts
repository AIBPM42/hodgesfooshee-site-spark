import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';

export interface City {
  slug: string;
  name: string;
  county: string;
  state: string;
  lat: number;
  lng: number;
  enabled: boolean;
  sort_order: number;
}

export const useCities = () => {
  return useQuery({
    queryKey: ['cities'],
    queryFn: async (): Promise<City[]> => {
      const { data, error } = await supabase
        .from('cities')
        .select('*')
        .eq('enabled', true)
        .order('sort_order', { ascending: true });

      if (error) {
        console.error('Error fetching cities:', error);
        throw error;
      }

      return data || [];
    },
    staleTime: 1000 * 60 * 30, // 30 minutes
  });
};