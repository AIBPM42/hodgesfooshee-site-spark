import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { PropertyListing } from './usePropertySearch';

export const useFeaturedListings = () => {
  return useQuery({
    queryKey: ['featured-listings'],
    queryFn: async (): Promise<PropertyListing[]> => {
      // First try to get featured listings
      const { data: featuredData, error: featuredError } = await supabase
        .from('featured_listings')
        .select(`
          listing_id,
          rank,
          mls_listings (
            id,
            mls_id,
            price,
            beds,
            baths,
            sqft,
            property_type,
            address,
            city,
            county,
            state,
            zip,
            photos
          )
        `)
        .order('rank', { ascending: true })
        .limit(12);

      if (!featuredError && featuredData && featuredData.length > 0) {
        return featuredData.map(item => ({
          id: item.mls_listings.id,
          mls_id: item.mls_listings.mls_id,
          price: item.mls_listings.price,
          beds: item.mls_listings.beds,
          baths: item.mls_listings.baths,
          sqft: item.mls_listings.sqft,
          property_type: item.mls_listings.property_type,
          address: item.mls_listings.address,
          city: item.mls_listings.city,
          county: item.mls_listings.county,
          state: item.mls_listings.state,
          zip: item.mls_listings.zip,
          thumb: item.mls_listings.photos?.[0] || '',
          photos: item.mls_listings.photos,
          total_count: 0
        }));
      }

      // Fallback to newest listings
      const { data: newestData, error: newestError } = await supabase
        .from('mls_listings')
        .select('id, mls_id, price, beds, baths, sqft, property_type, address, city, county, state, zip, photos')
        .eq('status', 'Active')
        .order('source_updated_at', { ascending: false })
        .limit(12);

      if (newestError) {
        console.error('Error fetching featured listings:', newestError);
        throw newestError;
      }

      return newestData?.map(item => ({
        ...item,
        thumb: item.photos?.[0] || '',
        total_count: 0
      })) || [];
    },
    staleTime: 1000 * 60 * 10, // 10 minutes
  });
};