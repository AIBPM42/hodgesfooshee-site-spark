import { useQuery } from '@tanstack/react-query';

interface PageBlock {
  slot: string;
  kind: string;
  payload: any;
  order: number;
}

interface PageBlocksResponse {
  page: string;
  blocks: PageBlock[];
  timestamp: string;
}

export const usePageBlocks = (pageName: string = 'home') => {
  return useQuery({
    queryKey: ['page-blocks', pageName],
    queryFn: async (): Promise<PageBlocksResponse> => {
      console.log('🚀 Fetching page blocks for:', pageName);
      const url = `https://xhqwmtzawqfffepcqxwf.supabase.co/functions/v1/api-site/page?name=${pageName}`;
      console.log('📡 Request URL:', url);
      
      try {
        const response = await fetch(url);
        console.log('📊 Response status:', response.status);
        console.log('📋 Response headers:', Object.fromEntries(response.headers.entries()));
        
        if (!response.ok) {
          const errorText = await response.text();
          console.error('❌ API Error:', response.status, errorText);
          throw new Error(`Failed to fetch page blocks: ${response.status} ${errorText}`);
        }
        
        const data = await response.json();
        console.log('✅ Page blocks data received:', data);
        console.log('🔢 Number of blocks:', data.blocks?.length || 0);
        
        return data;
      } catch (error) {
        console.error('🔥 usePageBlocks fetch error:', error);
        throw error;
      }
    },
    staleTime: 5 * 60 * 1000, // 5 minutes
    refetchOnWindowFocus: false,
    retry: 1
  });
};

export const useThemeTokens = () => {
  return useQuery({
    queryKey: ['theme-tokens'],
    queryFn: async () => {
      const response = await fetch('https://xhqwmtzawqfffepcqxwf.supabase.co/functions/v1/api-site/theme');
      if (!response.ok) {
        throw new Error('Failed to fetch theme tokens');
      }
      return response.json();
    },
    staleTime: 10 * 60 * 1000, // 10 minutes
    refetchOnWindowFocus: false,
  });
};

export const useFeatureFlags = () => {
  return useQuery({
    queryKey: ['feature-flags'],
    queryFn: async () => {
      const response = await fetch('https://xhqwmtzawqfffepcqxwf.supabase.co/functions/v1/api-site/feature-flags');
      if (!response.ok) {
        throw new Error('Failed to fetch feature flags');
      }
      return response.json();
    },
    staleTime: 2 * 60 * 1000, // 2 minutes
    refetchOnWindowFocus: false,
  });
};