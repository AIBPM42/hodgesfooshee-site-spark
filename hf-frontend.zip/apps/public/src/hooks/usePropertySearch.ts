import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';

// Use Realtyna MLS for live data when available, fallback to local data
const USE_REALTYNA_MLS = true; // Set to false to use local Supabase data

export interface SearchFilters {
  search_query?: string;
  filter_city?: string;
  min_price?: number;
  max_price?: number;
  min_beds?: number;
  max_beds?: number;
  min_baths?: number;
  max_baths?: number;
  sort_by?: 'price_asc' | 'price_desc' | 'newest' | 'beds_desc';
  page_limit?: number;
  page_offset?: number;
}

export interface PropertyListing {
  id: string;
  mls_id: string;
  price: number;
  beds: number;
  baths: number;
  sqft: number;
  property_type: string;
  address: string;
  city: string;
  county: string;
  state: string;
  zip: string;
  thumb: string;
  photos: any;
  total_count: number;
}

export const usePropertySearch = (filters: SearchFilters) => {
  return useQuery({
    queryKey: ['property-search', filters, USE_REALTYNA_MLS],
    queryFn: async (): Promise<PropertyListing[]> => {
      if (USE_REALTYNA_MLS) {
        // Use Realtyna MLS API for live data
        console.log('Searching Realtyna MLS with filters:', filters);
        
        const { data, error } = await supabase.functions.invoke('realtyna-mls-search', {
          body: {
            search_query: filters.search_query || '',
            filter_city: filters.filter_city || '',
            min_price: filters.min_price || 0,
            max_price: filters.max_price || 999999999,
            min_beds: filters.min_beds || 0,
            max_beds: filters.max_beds || 99,
            min_baths: filters.min_baths || 0,
            max_baths: filters.max_baths || 99,
            sort_by: filters.sort_by || 'price_desc',
            page_limit: filters.page_limit || 20,
            page_offset: filters.page_offset || 0
          }
        });

        if (error) {
          console.error('Realtyna MLS API error:', error);
          // Fallback to local data on error
          return useLocalData();
        }

        return data || [];
      } else {
        // Use local Supabase data
        return useLocalData();
      }

      async function useLocalData() {
        console.log('Using local Supabase data with filters:', filters);
        
        const { data, error } = await supabase.rpc('search_listings', {
          search_query: filters.search_query || '',
          filter_city: filters.filter_city || '',
          min_price: filters.min_price || 0,
          max_price: filters.max_price || 999999999,
          min_beds: filters.min_beds || 0,
          max_beds: filters.max_beds || 99,
          min_baths: filters.min_baths || 0,
          max_baths: filters.max_baths || 99,
          sort_by: filters.sort_by || 'price_desc',
          page_limit: filters.page_limit || 20,
          page_offset: filters.page_offset || 0
        });

        if (error) {
          console.error('Error searching local properties:', error);
          throw error;
        }

        return data || [];
      }
    },
    enabled: true,
    staleTime: USE_REALTYNA_MLS ? 1000 * 60 * 2 : 1000 * 60 * 5, // 2 min for live, 5 min for local
    retry: 2,
  });
};