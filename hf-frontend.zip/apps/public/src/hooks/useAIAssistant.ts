import { useState } from 'react';
import { supabase } from '@/integrations/supabase/client';

interface AIMessage {
  id: string;
  content: string;
  role: 'user' | 'assistant';
  timestamp: Date;
}

export const useAIAssistant = () => {
  const [messages, setMessages] = useState<AIMessage[]>([
    {
      id: '1',
      content: 'Hi! I\'m your AI assistant for Nashville Glass Estate. I can help you analyze opportunities, understand market trends, and answer questions about your listings. What would you like to know?',
      role: 'assistant',
      timestamp: new Date()
    }
  ]);
  const [isLoading, setIsLoading] = useState(false);

  const sendMessage = async (query: string) => {
    if (!query.trim()) return;

    // Add user message
    const userMessage: AIMessage = {
      id: Date.now().toString(),
      content: query,
      role: 'user',
      timestamp: new Date()
    };
    
    setMessages(prev => [...prev, userMessage]);
    setIsLoading(true);

    try {
      const { data, error } = await supabase.functions.invoke('ai-assistant', {
        body: { query }
      });

      if (error) {
        throw error;
      }

      // Add AI response
      const aiMessage: AIMessage = {
        id: (Date.now() + 1).toString(),
        content: data.response || 'I apologize, but I couldn\'t process your request.',
        role: 'assistant',
        timestamp: new Date()
      };
      
      setMessages(prev => [...prev, aiMessage]);

    } catch (error) {
      console.error('AI Assistant error:', error);
      
      // Add error message
      const errorMessage: AIMessage = {
        id: (Date.now() + 1).toString(),
        content: 'I\'m sorry, I\'m having trouble right now. Please try again later.',
        role: 'assistant',
        timestamp: new Date()
      };
      
      setMessages(prev => [...prev, errorMessage]);
    } finally {
      setIsLoading(false);
    }
  };

  const clearMessages = () => {
    setMessages([{
      id: '1',
      content: 'Hi! I\'m your AI assistant for Nashville Glass Estate. I can help you analyze opportunities, understand market trends, and answer questions about your listings. What would you like to know?',
      role: 'assistant',
      timestamp: new Date()
    }]);
  };

  return {
    messages,
    isLoading,
    sendMessage,
    clearMessages
  };
};