import React, { useState } from 'react';
import { Button } from './ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from './ui/dialog';
import { Input } from './ui/input';
import { Label } from './ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from './ui/select';


const exclusiveProperties = [
  {
    id: 1,
    image: "/lovable-uploads/ab180be1-43e7-4ed7-aa39-388e815ae240.png",
    area: "Belle Meade Area",
    priceRange: "$1.2M - $1.4M",
    type: "Historic Estate",
    features: "5+ Beds | 4+ Baths | 2+ Acres",
    status: "COMING SOON",
    statusColor: "bg-orange-500",
    teaser: "Rare historic estate with modern updates"
  },
  {
    id: 2,
    image: "/lovable-uploads/cb6505b7-cc3c-4bb2-b7ca-037735c27326.png",
    area: "Williamson County",
    priceRange: "$650K - $750K",
    type: "New Construction",
    features: "3+ Beds | 2+ Baths | Premium Finishes",
    status: "OFF-MARKET",
    statusColor: "bg-red-500",
    teaser: "Brand new luxury townhome in top-rated district"
  },
  {
    id: 3,
    image: "/lovable-uploads/8e257b61-50b0-4afa-a682-9f519bca8551.png",
    area: "Davidson County",
    priceRange: "$350K - $450K",
    type: "Investment Opportunity",
    features: "Multi-Unit | Cash Flow Positive",
    status: "EXCLUSIVE",
    statusColor: "bg-purple-500",
    teaser: "Turnkey rental property with proven returns"
  }
];

const NashvilleInsiderAccess = () => {
  const [showRegistrationModal, setShowRegistrationModal] = useState(false);
  const [selectedProperty, setSelectedProperty] = useState<typeof exclusiveProperties[0] | null>(null);

  const handleRegisterClick = (property: typeof exclusiveProperties[0]) => {
    setSelectedProperty(property);
    setShowRegistrationModal(true);
  };

  const triggerConfetti = () => {
    // Ensure confetti system is available
    if ((window as any).triggerConfettiCelebration) {
      (window as any).triggerConfettiCelebration();
    } else {
      // Fallback - wait a bit and try again
      setTimeout(() => {
        if ((window as any).triggerConfettiCelebration) {
          (window as any).triggerConfettiCelebration();
        }
      }, 500);
    }
  };

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Close modal first
    setShowRegistrationModal(false);
    // Trigger confetti celebration with delay
    setTimeout(() => {
      triggerConfetti();
    }, 100);
  };

  const handleGetInstantAccess = () => {
    // Trigger confetti for Get Instant Access button
    triggerConfetti();
    setShowRegistrationModal(true);
  };

  const handleScheduleConsultation = () => {
    // Trigger confetti for Schedule Private Consultation button
    triggerConfetti();
  };


  return (
    <section 
      className="relative py-20 px-4 sm:px-6 lg:px-8 overflow-hidden"
      style={{
        background: `linear-gradient(135deg, #2d2d2d 0%, #3d3d3d 30%, #4a4a4a 70%, #5a5a5a 100%)`
      }}
    >
      <div className="max-w-7xl mx-auto relative z-10">
        {/* Section Header */}
        <div className="text-center mb-16 animate-fade-in">
          <h2 className="text-4xl md:text-5xl font-extrabold text-white mb-4">
            Nashville Insider Access
          </h2>
          <p className="text-xl md:text-2xl text-gray-300 mb-6 font-medium">
            Exclusive opportunities before they hit the market
          </p>
          <p className="text-lg text-gray-400 max-w-3xl mx-auto">
            Get first access to off-market properties, coming soon listings, and investment opportunities through our insider network
          </p>
        </div>

        {/* Property Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-12 animate-fade-in animation-delay-300">
          {exclusiveProperties.map((property) => (
            <div
              key={property.id}
              className="group bg-white/10 backdrop-blur-md border border-white/20 rounded-2xl overflow-hidden transition-all duration-300 hover:scale-105 hover:-translate-y-2"
              style={{boxShadow: '0 35px 70px -12px rgba(0, 0, 0, 0.4)'}}
            >
              {/* Property Image with Blur Overlay */}
              <div className="relative h-48 overflow-hidden">
                <img
                  src={property.image}
                  alt={property.type}
                  className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-110"
                />
                {/* Teaser Blur Overlay */}
                <div className="absolute inset-0 bg-black/40 backdrop-blur-sm flex items-center justify-center">
                  <div className="text-white text-center">
                    <div className="text-sm font-semibold mb-2">EXCLUSIVE ACCESS</div>
                    <div className="text-xs opacity-80">Register to View Details</div>
                  </div>
                </div>
                {/* Status Badge */}
                <div className={`absolute top-4 left-4 ${property.statusColor} text-white px-3 py-1 rounded-xl text-xs font-semibold shadow-lg`}>
                  {property.status}
                </div>
              </div>

              {/* Card Content */}
              <div className="p-6">
                <div className="mb-4">
                  <h3 className="text-lg font-bold text-white mb-1">{property.type}</h3>
                  <p className="text-gray-300 text-sm">{property.area}</p>
                </div>

                <div className="space-y-2 mb-4">
                  <div className="flex justify-between items-center">
                    <span className="text-gray-400 text-sm">Price Range:</span>
                    <span className="font-semibold text-white text-sm">{property.priceRange}</span>
                  </div>
                  
                  <div className="text-center">
                    <span className="font-semibold text-white text-sm">{property.features}</span>
                  </div>
                </div>

                <p className="text-gray-300 text-sm mb-4 italic">
                  "{property.teaser}"
                </p>

                {/* Register Button */}
                <Button
                  onClick={() => handleRegisterClick(property)}
                  className="w-full bg-gradient-to-r from-[#FF4500] to-[#E55100] hover:from-[#E55100] hover:to-[#D84315] text-white font-semibold py-2 rounded-xl transition-all duration-300 hover:shadow-lg hover:shadow-orange-500/25"
                >
                  Register for Full Details
                </Button>
              </div>
            </div>
          ))}
        </div>

        {/* Main Call-to-Action */}
        <div className="text-center animate-fade-in animation-delay-600">
          <div 
            className="bg-white/10 backdrop-blur-md border border-white/20 rounded-2xl p-8 max-w-2xl mx-auto"
            style={{boxShadow: '0 35px 70px -12px rgba(0, 0, 0, 0.4)'}}
          >
            <h3 className="text-2xl font-bold text-white mb-4">
              Join Our Insider Network
            </h3>
            <p className="text-gray-300 mb-6">
              Get exclusive access to Nashville's hidden gems before they hit the public market. Our insider network gives you the competitive edge in today's fast-moving market.
            </p>
            <div className="flex flex-col md:flex-row gap-4 justify-center">
              <Button
                onClick={handleGetInstantAccess}
                size="lg"
                className="bg-gradient-to-r from-[#FF4500] to-[#E55100] hover:from-[#E55100] hover:to-[#D84315] text-white font-bold py-4 px-8 rounded-2xl text-lg transition-all duration-300 hover:shadow-lg hover:shadow-orange-500/25"
              >
                Get Instant Access
              </Button>
              <Button
                onClick={handleScheduleConsultation}
                size="lg"
                variant="outline"
                className="bg-white/10 backdrop-blur-md border-2 border-white/30 text-white font-semibold py-4 px-8 rounded-2xl text-lg hover:bg-white/20 transition-all duration-300"
              >
                Schedule Private Consultation
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Registration Modal with Glassmorphism */}
      <Dialog open={showRegistrationModal} onOpenChange={setShowRegistrationModal}>
        <DialogContent className="sm:max-w-md bg-white/10 backdrop-blur-xl border border-white/20 rounded-3xl shadow-2xl text-white">
          <DialogHeader>
            <DialogTitle className="text-center text-3xl font-bold text-white mb-2">
              Unlock Exclusive Access
            </DialogTitle>
            <p className="text-center text-white/80">
              Join Nashville's most trusted insider network
            </p>
          </DialogHeader>

          <form className="space-y-6 mt-8" onSubmit={handleFormSubmit}>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="firstName" className="text-white font-medium mb-2 block">
                  First Name
                </Label>
                <Input
                  id="firstName"
                  type="text"
                  placeholder="Enter your first name"
                  required
                  minLength={2}
                  className="bg-white/20 backdrop-blur-md border border-white/30 rounded-xl text-white placeholder-white/60 focus:border-orange-400 focus:ring-2 focus:ring-orange-400/20 focus:outline-none transition-all duration-300"
                />
              </div>
              
              <div>
                <Label htmlFor="lastName" className="text-white font-medium mb-2 block">
                  Last Name
                </Label>
                <Input
                  id="lastName"
                  type="text"
                  placeholder="Enter your last name"
                  required
                  minLength={2}
                  className="bg-white/20 backdrop-blur-md border border-white/30 rounded-xl text-white placeholder-white/60 focus:border-orange-400 focus:ring-2 focus:ring-orange-400/20 focus:outline-none transition-all duration-300"
                />
              </div>
            </div>

            <div>
              <Label htmlFor="email" className="text-white font-medium mb-2 block">
                Email Address
              </Label>
                <Input
                  id="email"
                  type="email"
                  placeholder="Enter your email address"
                  required
                  className="bg-white/20 backdrop-blur-md border border-white/30 rounded-xl text-white placeholder-white/60 focus:border-orange-400 focus:ring-2 focus:ring-orange-400/20 focus:outline-none transition-all duration-300"
                />
            </div>

            <div>
              <Label htmlFor="phone" className="text-white font-medium mb-2 block">
                Phone Number
              </Label>
                <Input
                  id="phone"
                  type="tel"
                  placeholder="Enter your phone number"
                  required
                  className="bg-white/20 backdrop-blur-md border border-white/30 rounded-xl text-white placeholder-white/60 focus:border-orange-400 focus:ring-2 focus:ring-orange-400/20 focus:outline-none transition-all duration-300"
                />
            </div>

            <div>
              <Label htmlFor="interest" className="text-white font-medium mb-2 block">
                Property Interest
              </Label>
              <Select required>
                <SelectTrigger className="bg-white/20 backdrop-blur-md border border-white/30 rounded-xl text-white focus:border-orange-400 focus:ring-2 focus:ring-orange-400/20 focus:outline-none transition-all duration-300">
                  <SelectValue placeholder="Select your interest" className="text-white/60" />
                </SelectTrigger>
                <SelectContent className="bg-white/90 backdrop-blur-md border border-white/30 rounded-xl">
                  <SelectItem value="buying">Buying a Home</SelectItem>
                  <SelectItem value="investment">Investment Properties</SelectItem>
                  <SelectItem value="luxury">Luxury Properties</SelectItem>
                  <SelectItem value="coming-soon">Coming Soon Listings</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="flex gap-4 pt-4">
              <Button
                type="button"
                onClick={() => setShowRegistrationModal(false)}
                className="flex-1 bg-white/20 backdrop-blur-md border border-white/30 text-white hover:bg-white/30 transition-all duration-300 rounded-xl"
              >
                Cancel
              </Button>
              <Button
                type="submit"
                className="flex-1 bg-gradient-to-r from-[#FF4500] to-[#E55100] hover:from-[#E55100] hover:to-[#D84315] text-white font-semibold hover:scale-105 transition-all duration-300 shadow-lg hover:shadow-xl rounded-xl"
              >
                Get Access Now
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>

    </section>
  );
};

export default NashvilleInsiderAccess;