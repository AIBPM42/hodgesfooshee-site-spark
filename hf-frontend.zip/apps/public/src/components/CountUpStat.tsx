import React, { useState, useEffect, useRef } from 'react';

interface CountUpStatProps {
  end: number;
  duration: number;
  suffix?: string;
  delay?: number;
}

const CountUpStat: React.FC<CountUpStatProps> = ({ 
  end, 
  duration, 
  suffix = "", 
  delay = 0 
}) => {
  const [count, setCount] = useState(0);
  const [isVisible, setIsVisible] = useState(false);
  const [hasAnimated, setHasAnimated] = useState(false);
  const ref = useRef<HTMLSpanElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting && !hasAnimated) {
          setIsVisible(true);
          setHasAnimated(true);
          startCountUp();
        }
      },
      { 
        threshold: 0.5,
        rootMargin: '0px 0px -50px 0px'
      }
    );

    if (ref.current) {
      observer.observe(ref.current);
    }

    return () => observer.disconnect();
  }, [hasAnimated]);

  const startCountUp = () => {
    setTimeout(() => {
      const startTime = Date.now();
      const durationMs = duration * 1000;
      
      const animate = () => {
        const elapsed = Date.now() - startTime;
        const progress = Math.min(elapsed / durationMs, 1);
        
        // Ease-out function for natural deceleration
        const easeOut = 1 - Math.pow(1 - progress, 3);
        const currentCount = Math.floor(easeOut * end);
        
        setCount(currentCount);
        
        if (progress < 1) {
          requestAnimationFrame(animate);
        } else {
          setCount(end);
        }
      };
      
      requestAnimationFrame(animate);
    }, delay);
  };

  return (
    <span 
      ref={ref}
      className="text-3xl md:text-4xl font-extrabold mb-1 bg-gradient-to-br from-white to-white/80 bg-clip-text text-transparent transition-transform duration-300"
      style={{
        WebkitBackgroundClip: 'text', 
        WebkitTextFillColor: 'transparent',
        transform: isVisible ? 'scale(1.02)' : 'scale(1)'
      }}
    >
      {count}{suffix}
    </span>
  );
};

export default CountUpStat;