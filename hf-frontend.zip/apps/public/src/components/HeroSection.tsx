import React from 'react';
import PropertySearch from './PropertySearch';
import CountUpStat from './CountUpStat';
import nashvilleHome from '../assets/nashville-luxury-home.jpg';

const HeroSection = () => {
  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden pt-20" style={{
      backgroundImage: `url('/nashville-luxury-home.jpg')`,
      backgroundSize: 'cover',
      backgroundPosition: 'center',
      backgroundRepeat: 'no-repeat'
    }}>
      {/* Background Image with Overlay - Using direct styling */}
      <div className="absolute inset-0" style={{
        background: 'linear-gradient(135deg, rgba(0, 0, 0, 0.7) 0%, rgba(0, 0, 0, 0.4) 50%, rgba(14, 93, 145, 0.3) 100%)'
      }}></div>

      {/* Content */}
      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        {/* Hero Text */}
        <div className="mb-12 animate-fade-in">
          <h1 className="text-5xl md:text-7xl font-black text-white mb-6 leading-tight text-center px-5 md:px-0" style={{
            textShadow: '0 8px 32px rgba(0, 0, 0, 0.8), 0 4px 16px rgba(0, 0, 0, 0.6)',
            filter: 'drop-shadow(0 4px 8px rgba(0, 0, 0, 0.3))'
          }}>
            Your Source for{' '}
            <span 
              className="text-accent" 
              style={{
                textShadow: '0 8px 32px hsl(var(--accent) / 0.4), 0 4px 16px rgba(0, 0, 0, 0.8)',
                filter: 'drop-shadow(0 4px 8px hsl(var(--accent) / 0.2))',
                fontWeight: '900'
              }}
            >
              Nashville Real Estate
            </span>{' '}
            Excellence
          </h1>
          <p className="text-xl md:text-2xl text-white font-medium max-w-3xl mx-auto text-center px-5 md:px-0 mb-10" style={{
            textShadow: '0 4px 16px rgba(0, 0, 0, 0.7), 0 2px 8px rgba(0, 0, 0, 0.5)',
            filter: 'drop-shadow(0 2px 4px rgba(0, 0, 0, 0.3))'
          }}>
            Discover exceptional properties across Middle Tennessee with Nashville&apos;s most trusted real estate experts
          </p>
        </div>

        {/* Property Search Component with Premium Glass Effect */}
        <div className="animate-fade-in animation-delay-300 max-w-5xl mx-auto">
          <div className="backdrop-blur-2xl bg-white/10 border border-white/20 rounded-3xl p-8 shadow-2xl" style={{
            backdropFilter: 'blur(24px)',
            WebkitBackdropFilter: 'blur(24px)',
            boxShadow: '0 25px 50px -12px rgba(0, 0, 0, 0.8), 0 0 0 1px rgba(255, 255, 255, 0.1) inset'
          }}>
            <PropertySearch />
          </div>
        </div>

        {/* Trust Indicators */}
        <div className="mt-10 md:mt-16 animate-fade-in animation-delay-600 mx-5 md:mx-0">
          <div 
            className="bg-white/25 backdrop-blur-lg border border-white/20 rounded-2xl p-5 md:px-10 md:py-6 flex flex-col md:flex-row justify-around items-center gap-5 md:gap-8 max-w-4xl mx-auto"
            style={{
              backdropFilter: 'blur(20px)',
              WebkitBackdropFilter: 'blur(20px)',
              boxShadow: 'var(--glass-shadow)'
            }}
          >
            <div className="text-center text-white">
              <div>
                <CountUpStat end={500} duration={2.5} suffix="+" delay={0} />
              </div>
              <div className="text-white/90 font-medium">Homes Sold</div>
            </div>
            <div className="text-center text-white">
              <div>
                <CountUpStat end={25} duration={2.0} suffix="+" delay={200} />
              </div>
              <div className="text-white/90 font-medium">Years Experience</div>
            </div>
            <div className="text-center text-white">
              <div>
                <CountUpStat end={9} duration={1.5} suffix="" delay={400} />
              </div>
              <div className="text-white/90 font-medium">Counties Served</div>
            </div>
            <div className="text-center text-white">
              <div>
                <CountUpStat end={98} duration={2.0} suffix="%" delay={600} />
              </div>
              <div className="text-white/90 font-medium">Client Satisfaction</div>
            </div>
          </div>
        </div>
      </div>

      {/* Scroll Indicator */}
      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 animate-bounce">
        <div className="w-6 h-10 border-2 border-white/40 rounded-full flex justify-center">
          <div className="w-1 h-3 bg-white/60 rounded-full mt-2 animate-pulse"></div>
        </div>
      </div>
    </section>
  );
};

export default HeroSection;