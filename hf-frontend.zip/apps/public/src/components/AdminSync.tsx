import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import { useQuery } from '@tanstack/react-query';
import { Loader2, Database, RefreshCw, CheckCircle } from 'lucide-react';

interface SyncStatus {
  raw_listings: {
    count: number;
    latest_ingestion: string | null;
  };
  processed_listings: {
    count: number;
    latest_update: string | null;
  };
  cities: {
    count: number;
  };
  timestamp: string;
}

export const AdminSync = () => {
  const [issyncing, setIsSyncing] = useState(false);
  const [syncStatus, setSyncStatus] = useState<SyncStatus | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  // Add queries for content management
  const { data: pageBlocks, isLoading: blocksLoading } = useQuery({
    queryKey: ['admin-page-blocks'],
    queryFn: async () => {
      const { data } = await supabase
        .from('page_blocks')
        .select('*')
        .order('page, order_index');
      return data || [];
    },
  });

  const { data: posts, isLoading: postsLoading } = useQuery({
    queryKey: ['admin-posts'],
    queryFn: async () => {
      const { data } = await supabase
        .from('posts')
        .select('*, authors(name)')
        .order('created_at', { ascending: false });
      return data || [];
    },
  });

  const { data: themeTokens } = useQuery({
    queryKey: ['admin-theme-tokens'],
    queryFn: async () => {
      const { data } = await supabase
        .from('theme_tokens')
        .select('*')
        .order('key');
      return data || [];
    },
  });

  const { data: featureFlags } = useQuery({
    queryKey: ['admin-feature-flags'],
    queryFn: async () => {
      const { data } = await supabase
        .from('feature_flags')
        .select('*')
        .order('key');
      return data || [];
    },
  });

  const triggerSync = async () => {
    setIsSyncing(true);
    try {
      const { data, error } = await supabase.functions.invoke('sync-mls-data', {});
      
      if (error) throw error;

      toast.success('MLS sync completed successfully!');
      console.log('Sync result:', data);
      
      // Refresh status after sync
      setTimeout(() => {
        fetchSyncStatus();
      }, 1000);
      
    } catch (error) {
      console.error('Sync error:', error);
      toast.error('MLS sync failed. Please check the logs.');
    } finally {
      setIsSyncing(false);
    }
  };

  const fetchSyncStatus = async () => {
    setIsLoading(true);
    try {
      // Call backend admin endpoint for status
      const response = await fetch('/admin/sync/status');
      if (!response.ok) throw new Error('Failed to fetch status');
      
      const data = await response.json();
      setSyncStatus(data);
    } catch (error) {
      console.error('Status fetch error:', error);
      
      // Fallback: get basic counts directly from Supabase
      try {
        const [rawCount, processedCount, citiesCount] = await Promise.all([
          supabase.from('mls_raw_listings').select('id', { count: 'exact', head: true }),
          supabase.from('mls_listings').select('id', { count: 'exact', head: true }),
          supabase.from('cities').select('slug', { count: 'exact', head: true })
        ]);

        setSyncStatus({
          raw_listings: { count: rawCount.count || 0, latest_ingestion: null },
          processed_listings: { count: processedCount.count || 0, latest_update: null },
          cities: { count: citiesCount.count || 0 },
          timestamp: new Date().toISOString()
        });
      } catch (fallbackError) {
        toast.error('Failed to fetch sync status');
      }
    } finally {
      setIsLoading(false);
    }
  };

  React.useEffect(() => {
    fetchSyncStatus();
  }, []);

  const formatDate = (dateString: string | null) => {
    if (!dateString) return 'Never';
    return new Intl.DateTimeFormat('en-US', {
      dateStyle: 'medium',
      timeStyle: 'short'
    }).format(new Date(dateString));
  };

  return (
    <div className="min-h-screen bg-background p-4">
      <div className="max-w-6xl mx-auto">
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2">Nashville Glass Estate Admin</h1>
          <p className="text-muted-foreground">
            Manage your real estate platform content and data
          </p>
        </div>

        <Tabs defaultValue="content" className="space-y-6">
          <TabsList className="grid grid-cols-5 w-full">
            <TabsTrigger value="content">Content</TabsTrigger>
            <TabsTrigger value="blog">Blog</TabsTrigger>
            <TabsTrigger value="theme">Theme</TabsTrigger>
            <TabsTrigger value="features">Features</TabsTrigger>
            <TabsTrigger value="mls">MLS Sync</TabsTrigger>
          </TabsList>

          <TabsContent value="content">
            <Card>
              <CardHeader>
                <CardTitle>Page Blocks Management</CardTitle>
                <CardDescription>
                  Manage dynamic page content blocks for your website
                </CardDescription>
              </CardHeader>
              <CardContent>
                {blocksLoading ? (
                  <div className="flex items-center justify-center py-8">
                    <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {pageBlocks?.map((block) => (
                      <div key={block.id} className="flex items-center justify-between p-4 border rounded-lg">
                        <div>
                          <div className="flex items-center gap-2 mb-1">
                            <Badge variant="outline">{block.page}</Badge>
                            <Badge variant="secondary">{block.slot}</Badge>
                            <Badge>{block.kind}</Badge>
                          </div>
                          <p className="text-sm text-muted-foreground">
                            Order: {block.order_index} | State: {block.state}
                          </p>
                        </div>
                        <div className="flex items-center gap-2">
                          <Badge variant={block.is_enabled ? "default" : "destructive"}>
                            {block.is_enabled ? "Enabled" : "Disabled"}
                          </Badge>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="blog">
            <Card>
              <CardHeader>
                <CardTitle>Blog Posts</CardTitle>
                <CardDescription>
                  Manage blog posts and content
                </CardDescription>
              </CardHeader>
              <CardContent>
                {postsLoading ? (
                  <div className="flex items-center justify-center py-8">
                    <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {posts?.map((post) => (
                      <div key={post.id} className="flex items-center justify-between p-4 border rounded-lg">
                        <div>
                          <h3 className="font-semibold">{post.title}</h3>
                          <p className="text-sm text-muted-foreground">
                            By {post.authors?.name || 'Unknown'} | 
                            {post.published_at ? ` Published: ${new Date(post.published_at).toLocaleDateString()}` : ' Draft'}
                          </p>
                        </div>
                        <Badge variant={post.published_at ? "default" : "secondary"}>
                          {post.published_at ? "Published" : "Draft"}
                        </Badge>
                      </div>
                    ))}
                    {(!posts || posts.length === 0) && (
                      <p className="text-center text-muted-foreground py-8">
                        No blog posts yet. Create your first post to get started.
                      </p>
                    )}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="theme">
            <Card>
              <CardHeader>
                <CardTitle>Theme Tokens</CardTitle>
                <CardDescription>
                  Manage design system colors and styling
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {themeTokens?.map((token) => (
                    <div key={token.key} className="flex items-center justify-between p-3 border rounded">
                      <div>
                        <code className="text-sm font-mono">{token.key}</code>
                        <p className="text-sm text-muted-foreground mt-1">{token.value}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="features">
            <Card>
              <CardHeader>
                <CardTitle>Feature Flags</CardTitle>
                <CardDescription>
                  Toggle features and run A/B tests
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {featureFlags?.map((flag) => (
                    <div key={flag.key} className="flex items-center justify-between p-4 border rounded-lg">
                      <div>
                        <code className="text-sm font-mono">{flag.key}</code>
                        {flag.payload && (
                          <p className="text-sm text-muted-foreground mt-1">
                            Config: {JSON.stringify(flag.payload)}
                          </p>
                        )}
                      </div>
                      <Badge variant={flag.enabled ? "default" : "secondary"}>
                        {flag.enabled ? "Enabled" : "Disabled"}
                      </Badge>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="mls">
            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <div>
                  <h2 className="text-2xl font-bold">MLS Data Administration</h2>
                  <p className="text-muted-foreground">Manage live MLS data synchronization</p>
                </div>
                <Button 
                  onClick={triggerSync} 
                  disabled={issyncing}
                  className="gap-2"
                >
                  {issyncing ? (
                    <Loader2 className="w-4 h-4 animate-spin" />
                  ) : (
                    <RefreshCw className="w-4 h-4" />
                  )}
                  {issyncing ? 'Syncing...' : 'Sync MLS Data'}
                </Button>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <Card>
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm font-medium">Raw Listings</CardTitle>
                    <Database className="w-4 h-4 text-muted-foreground" />
                  </CardHeader>
                  <CardContent>
                    {isLoading ? (
                      <div className="flex items-center space-x-2">
                        <Loader2 className="w-4 h-4 animate-spin" />
                        <span className="text-sm">Loading...</span>
                      </div>
                    ) : (
                      <>
                        <div className="text-2xl font-bold">
                          {syncStatus?.raw_listings.count || 0}
                        </div>
                        <p className="text-xs text-muted-foreground">
                          Last ingestion: {formatDate(syncStatus?.raw_listings.latest_ingestion || null)}
                        </p>
                      </>
                    )}
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm font-medium">Processed Listings</CardTitle>
                    <CheckCircle className="w-4 h-4 text-muted-foreground" />
                  </CardHeader>
                  <CardContent>
                    {isLoading ? (
                      <div className="flex items-center space-x-2">
                        <Loader2 className="w-4 h-4 animate-spin" />
                        <span className="text-sm">Loading...</span>
                      </div>
                    ) : (
                      <>
                        <div className="text-2xl font-bold">
                          {syncStatus?.processed_listings.count || 0}
                        </div>
                        <p className="text-xs text-muted-foreground">
                          Last update: {formatDate(syncStatus?.processed_listings.latest_update || null)}
                        </p>
                      </>
                    )}
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm font-medium">Cities</CardTitle>
                    <Badge variant="secondary">{syncStatus?.cities.count || 0}</Badge>
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">
                      {syncStatus?.cities.count || 0}
                    </div>
                    <p className="text-xs text-muted-foreground">
                      Available locations
                    </p>
                  </CardContent>
                </Card>
              </div>

              <Card>
                <CardHeader>
                  <CardTitle>Sync Status</CardTitle>
                  <CardDescription>
                    Current state of MLS data synchronization
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="text-sm">Data Pipeline Status</span>
                    <Badge variant={syncStatus?.processed_listings.count ? "default" : "secondary"}>
                      {syncStatus?.processed_listings.count ? "Active" : "No Data"}
                    </Badge>
                  </div>
                  
                  <div className="text-xs text-muted-foreground">
                    Last status check: {syncStatus ? formatDate(syncStatus.timestamp) : 'Loading...'}
                  </div>

                  <Button 
                    variant="outline" 
                    onClick={fetchSyncStatus} 
                    disabled={isLoading}
                    className="w-full"
                  >
                    {isLoading ? (
                      <>
                        <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                        Refreshing...
                      </>
                    ) : (
                      'Refresh Status'
                    )}
                  </Button>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};