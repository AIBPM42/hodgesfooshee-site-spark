import React, { useState, useEffect } from 'react';
import { useSearchParams, useNavigate } from 'react-router-dom';
// UI components removed - using simple HTML elements instead
import { Search, MapPin, Bed, Bath, DollarSign, Home, Hash } from 'lucide-react';
// Hook removed - using simple state management instead

export const PropertiesHero = () => {
  const [searchParams, setSearchParams] = useSearchParams();
  const navigate = useNavigate();
  const { data: cities, isLoading: citiesLoading } = useCities();
  
  const [searchQuery, setSearchQuery] = useState(searchParams.get('q') || '');
  const [propertyType, setPropertyType] = useState(searchParams.get('property_type') || 'all');
  const [city, setCity] = useState(searchParams.get('city') || 'all');
  const [beds, setBeds] = useState(searchParams.get('beds') || '');
  const [baths, setBaths] = useState(searchParams.get('baths') || '');
  const [topResults, setTopResults] = useState(searchParams.get('limit') || '20');
  const [priceRange, setPriceRange] = useState([
    parseInt(searchParams.get('min_price') || '100000'),
    parseInt(searchParams.get('max_price') || '1000000')
  ]);

  // Update state when URL params change
  useEffect(() => {
    setSearchQuery(searchParams.get('q') || '');
    setPropertyType(searchParams.get('property_type') || 'all');
    setCity(searchParams.get('city') || 'all');
    setBeds(searchParams.get('beds') || '');
    setBaths(searchParams.get('baths') || '');
    setTopResults(searchParams.get('limit') || '20');
    setPriceRange([
      parseInt(searchParams.get('min_price') || '100000'),
      parseInt(searchParams.get('max_price') || '1000000')
    ]);
  }, [searchParams]);

  const propertyTypes = [
    'Single Family Residential',
    'Condominium',
    'Townhouse',
    'Multi-Family',
    'Land/Lots',
    'Commercial'
  ];

  const handleSearch = () => {
    const params = new URLSearchParams();
    
    if (searchQuery.trim()) params.set('q', searchQuery.trim());
    if (city && city !== 'all') params.set('city', city);
    if (propertyType && propertyType !== 'all') params.set('property_type', propertyType);
    if (beds) params.set('beds', beds);
    if (baths) params.set('baths', baths);
    if (topResults && topResults !== '20') params.set('limit', topResults);
    if (priceRange[0] > 100000) params.set('min_price', priceRange[0].toString());
    if (priceRange[1] < 1000000) params.set('max_price', priceRange[1].toString());

    setSearchParams(params);
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      handleSearch();
    }
  };

  return (
    <div className="relative min-h-[60vh] bg-gradient-to-br from-primary/20 via-primary/10 to-secondary/20 flex items-center justify-center px-4 py-12">
      {/* Background with glassmorphism effect */}
      <div className="absolute inset-0 bg-gradient-to-br from-accent/20 to-primary/30" />
      
      <div className="relative w-full max-w-6xl mx-auto">
        {/* Page Header */}
        <div className="text-center mb-8">
          <h1 className="text-4xl md:text-5xl font-bold text-white mb-4">
            Live MLS Property Search
          </h1>
          <p className="text-xl text-white/80 max-w-2xl mx-auto">
            Search live Nashville area MLS listings with real-time results
          </p>
        </div>

        {/* Main Search Interface */}
        <div className="bg-white/25 backdrop-blur-lg rounded-2xl border border-white/20 shadow-lg p-6" style={{boxShadow: 'var(--glass-shadow)'}}>
          
          {/* Search Input */}
          <div className="mb-6">
            <div className="relative">
              <Search className="absolute left-3 top-3 h-4 w-4 text-white/60" />
              <Input
                placeholder="Search by address, neighborhood, MLS#..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                onKeyPress={handleKeyPress}
                className="pl-10 bg-white/10 border-white/30 text-white placeholder:text-white/60 h-12 text-lg backdrop-blur-sm"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-6 gap-4 items-end">
            {/* Property Type */}
            <div className="space-y-2">
              <label className="text-sm font-medium text-white/90 flex items-center">
                <Home className="w-4 h-4 mr-2" />
                Property Type
              </label>
              <Select value={propertyType} onValueChange={setPropertyType}>
                <SelectTrigger className="bg-white/20 border-white/30 text-white backdrop-blur-sm hover:bg-white/30 transition-all">
                  <SelectValue placeholder="Any Type" />
                </SelectTrigger>
                <SelectContent className="bg-white/95 backdrop-blur-xl border-white/20">
                  <SelectItem value="all">All Types</SelectItem>
                  {propertyTypes.map((type) => (
                    <SelectItem key={type} value={type.toLowerCase()}>
                      {type}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Location */}
            <div className="space-y-2">
              <label className="text-sm font-medium text-white/90 flex items-center">
                <MapPin className="w-4 h-4 mr-2" />
                Location
              </label>
              <Input
                type="text"
                placeholder="Enter city or area"
                value={city === 'all' ? '' : city}
                onChange={(e) => setCity(e.target.value || 'all')}
                onKeyPress={handleKeyPress}
                className="bg-white/20 border-white/30 text-white placeholder:text-white/60 backdrop-blur-sm hover:bg-white/30 transition-all"
              />
            </div>

            {/* Bedrooms */}
            <div className="space-y-2">
              <label className="text-sm font-medium text-white/90 flex items-center">
                <Bed className="w-4 h-4 mr-2" />
                Min Beds
              </label>
              <Input
                type="number"
                placeholder="Any"
                value={beds}
                onChange={(e) => setBeds(e.target.value)}
                className="bg-white/20 border-white/30 text-white placeholder:text-white/60 backdrop-blur-sm hover:bg-white/30 transition-all"
                min="1"
                max="10"
              />
            </div>

            {/* Bathrooms */}
            <div className="space-y-2">
              <label className="text-sm font-medium text-white/90 flex items-center">
                <Bath className="w-4 h-4 mr-2" />
                Min Baths
              </label>
              <Input
                type="number"
                placeholder="Any"
                value={baths}
                onChange={(e) => setBaths(e.target.value)}
                className="bg-white/20 border-white/30 text-white placeholder:text-white/60 backdrop-blur-sm hover:bg-white/30 transition-all"
                min="1"
                max="10"
                step="0.5"
              />
            </div>

            {/* Top Results */}
            <div className="space-y-2">
              <label className="text-sm font-medium text-white/90 flex items-center">
                <Hash className="w-4 h-4 mr-2" />
                Top (1-50)
              </label>
              <Input
                type="number"
                placeholder="20"
                value={topResults}
                onChange={(e) => setTopResults(e.target.value)}
                className="bg-white/20 border-white/30 text-white placeholder:text-white/60 backdrop-blur-sm hover:bg-white/30 transition-all"
                min="1"
                max="50"
              />
            </div>

            {/* Search Button */}
            <div className="space-y-2">
              <label className="text-sm font-medium text-transparent">Search</label>
              <Button 
                onClick={handleSearch}
                className="w-full bg-accent hover:bg-accent/90 text-white font-semibold h-10 transition-all duration-300 hover:scale-105 shadow-lg"
              >
                <Search className="w-4 h-4 mr-2" />
                Update Results
              </Button>
            </div>
          </div>

          {/* Price Range Slider */}
          <div className="mt-6 pt-6 border-t border-white/20">
            <div className="flex items-center justify-between mb-4">
              <label className="text-sm font-medium text-white/90 flex items-center">
                <DollarSign className="w-4 h-4 mr-2" />
                Price Range
              </label>
              <div className="text-sm text-white/80">
                ${priceRange[0].toLocaleString()} - ${priceRange[1].toLocaleString()}
              </div>
            </div>
            <Slider
              value={priceRange}
              onValueChange={setPriceRange}
              max={2000000}
              min={50000}
              step={25000}
              className="w-full"
            />
          </div>
        </div>
      </div>
    </div>
  );
};