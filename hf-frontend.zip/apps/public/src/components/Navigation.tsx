import React, { useState } from "react";
import { Link } from "react-router-dom";

export default function Navigation() {
  const [open, setOpen] = useState(false);
  
  return (
    <header className="sticky top-0 z-50 w-full backdrop-blur-2xl bg-white/10 border-b border-white/20" style={{
      backdropFilter: 'blur(24px)',
      WebkitBackdropFilter: 'blur(24px)',
      boxShadow: '0 8px 32px rgba(0, 0, 0, 0.1)'
    }}>
      <div className="mx-auto max-w-7xl px-4 py-4 flex items-center justify-between">
        <Link to="/" className="font-semibold">
          <img 
            src="/lovable-uploads/d415eba1-80f0-4607-a0c2-60d6406d60c6.png" 
            alt="Hodges & Fooshee Realty Logo" 
            className="h-12 w-auto object-contain"
          />
        </Link>
        <nav className="hidden md:flex items-center gap-8">
          <Link to="/" className="hover:opacity-80 text-white font-medium transition-opacity">Home</Link>
          <Link to="/listings" className="hover:opacity-80 text-white font-medium transition-opacity">Property Search</Link>
          <Link to="/blog" className="hover:opacity-80 text-white font-medium transition-opacity">Market Insights</Link>
          <Link to="/ai" className="hover:opacity-80 text-white font-medium transition-opacity">AI Intelligence</Link>
          <a href="/contact" className="inline-flex items-center rounded-xl px-6 py-3 bg-accent hover:bg-accent/90 text-white font-semibold transition-all duration-300 hover:scale-105 shadow-lg">
            Contact
          </a>
        </nav>
        <button
          className="md:hidden inline-flex items-center rounded-lg px-3 py-2 border border-white/20 text-white"
          onClick={() => setOpen(v => !v)}
          aria-expanded={open}
          aria-label="Toggle menu"
        >
          Menu
        </button>
      </div>
      {open && (
        <div className="md:hidden border-t border-white/10 bg-black/50">
          <div className="px-4 py-3 flex flex-col gap-3">
            <Link to="/" onClick={()=>setOpen(false)} className="text-white">Home</Link>
            <Link to="/listings" onClick={()=>setOpen(false)} className="text-white">Property Search</Link>
            <Link to="/blog" onClick={()=>setOpen(false)} className="text-white">Market Insights</Link>
            <Link to="/ai" onClick={()=>setOpen(false)} className="text-white">AI Intelligence</Link>
            <a href="/contact" className="inline-flex items-center rounded-xl px-6 py-3 bg-accent hover:bg-accent/90 text-white font-semibold transition-all duration-300">
              Contact
            </a>
          </div>
        </div>
      )}
    </header>
  );
}