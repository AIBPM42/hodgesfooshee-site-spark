import React from 'react';
import { PropertyListing } from '@/hooks/usePropertySearch';
import { Bed, Bath, Square, MapPin } from 'lucide-react';

interface PropertyResultCardProps {
  property: PropertyListing;
}

export const PropertyResultCard: React.FC<PropertyResultCardProps> = ({ property }) => {
  return (
    <div className="bg-white/20 backdrop-blur-lg rounded-xl border border-white/30 p-6 hover:bg-white/25 transition-all duration-300 shadow-lg">
      {/* Property Image */}
      {property.thumb && (
        <div className="relative mb-4 rounded-lg overflow-hidden">
          <img 
            src={property.thumb} 
            alt={property.address}
            className="w-full h-48 object-cover"
          />
          <div className="absolute top-3 right-3 bg-accent/90 text-white px-3 py-1 rounded-full text-sm font-semibold">
            ${property.price?.toLocaleString()}
          </div>
        </div>
      )}

      {/* Property Details */}
      <div className="space-y-3">
        <div>
          <h3 className="text-lg font-semibold text-white mb-1">
            {property.address}
          </h3>
          <p className="text-white/80 text-sm flex items-center">
            <MapPin className="w-4 h-4 mr-1" />
            {property.city}, {property.state} {property.zip}
          </p>
        </div>

        <div className="grid grid-cols-3 gap-4 text-white/90">
          <div className="flex items-center">
            <Bed className="w-4 h-4 mr-2" />
            <span className="text-sm">{property.beds} bed{property.beds !== 1 ? 's' : ''}</span>
          </div>
          <div className="flex items-center">
            <Bath className="w-4 h-4 mr-2" />
            <span className="text-sm">{property.baths} bath{property.baths !== 1 ? 's' : ''}</span>
          </div>
          <div className="flex items-center">
            <Square className="w-4 h-4 mr-2" />
            <span className="text-sm">{property.sqft?.toLocaleString()} sq ft</span>
          </div>
        </div>

        <div className="pt-2 border-t border-white/20">
          <p className="text-xs text-white/60">
            MLS# {property.mls_id} • {property.property_type}
          </p>
        </div>
      </div>
    </div>
  );
};