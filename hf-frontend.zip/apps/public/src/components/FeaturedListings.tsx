import PropertyCard from './PropertyCard';
import { useNavigate } from 'react-router-dom';
import { ChevronLeft, ChevronRight, ArrowRight } from 'lucide-react';
import { useRef } from 'react';

// Mock listings for fallback when API data isn't available
const mockListings = [
  { price: 525000, beds: 3, baths: 2.5, sqft: 2100, address: "Green Hills Area" },
  { price: 675000, beds: 4, baths: 3, sqft: 2800, address: "Belle Meade" },
  { price: 450000, beds: 3, baths: 2, sqft: 1850, address: "East Nashville" },
  { price: 750000, beds: 4, baths: 3.5, sqft: 3200, address: "Music Row" },
  { price: 395000, beds: 2, baths: 2, sqft: 1650, address: "The Nations" },
  { price: 850000, beds: 5, baths: 4, sqft: 3800, address: "Brentwood" },
  { price: 425000, beds: 3, baths: 2, sqft: 1900, address: "Germantown" },
  { price: 620000, beds: 4, baths: 3, sqft: 2600, address: "Sylvan Park" }
];

interface FeaturedListingsProps {
  dataMode?: 'static' | 'live';
}

export const FeaturedListings: React.FC<FeaturedListingsProps> = ({ dataMode = 'live' }) => {
  // Skip data fetching for static mode and just show fallback
  const navigate = useNavigate();
  const scrollContainerRef = useRef<HTMLDivElement>(null);

  // For static mode (home page), always show the fallback content without fetching
  if (dataMode === 'static') {
    return (
      <section className="py-16 bg-gradient-to-b from-background/50 to-background">
        <div className="container mx-auto px-4">
          <div className="text-center mb-8">
            <h2 className="text-3xl font-bold mb-2">Fresh on the Market</h2>
            <p className="text-muted-foreground">Discover the latest premium properties in Nashville</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {Array.from({ length: 8 }).map((_, index) => (
              <div key={index} className="bg-background/40 backdrop-blur-md rounded-lg h-64 animate-pulse" />
            ))}
          </div>
        </div>
      </section>
    );
  // Show fallback content when no real listings available or in static mode
  return (
      <section className="py-16 bg-gradient-to-b from-background/50 to-background">
        <div className="container mx-auto px-4">
          <div className="text-center mb-8">
            <h2 className="text-3xl font-bold mb-2 bg-gradient-to-r from-primary to-primary/70 bg-clip-text text-transparent">
              Fresh on the Market
            </h2>
            <p className="text-muted-foreground text-lg">
              Discover premium properties across Nashville
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            {mockListings.map((listing, index) => (
              <div key={index} className="bg-card border border-border rounded-lg overflow-hidden hover:shadow-lg transition-shadow">
                <div className="h-48 bg-gradient-to-br from-primary/10 to-accent/10 flex items-center justify-center">
                  <div className="text-center">
                    <div className="w-16 h-16 bg-primary/20 rounded-full flex items-center justify-center mb-2 mx-auto">
                      <span className="text-2xl font-bold text-primary">{listing.beds}</span>
                    </div>
                    <p className="text-sm text-muted-foreground">Bedroom Home</p>
                  </div>
                </div>
                <div className="p-4">
                  <h3 className="font-bold text-lg text-foreground mb-1">${listing.price.toLocaleString()}</h3>
                  <p className="text-sm text-muted-foreground mb-2">{listing.address}</p>
                  <div className="flex items-center text-xs text-muted-foreground space-x-4">
                    <span>{listing.beds} bd</span>
                    <span>{listing.baths} ba</span>
                    <span>{listing.sqft.toLocaleString()} sqft</span>
                  </div>
                </div>
              </div>
            ))}
          </div>

          <div className="text-center">
            <button
              onClick={() => navigate('/listings')}
              className="bg-orange-500 hover:bg-orange-600 text-white px-8 py-3 text-lg font-semibold rounded-md inline-flex items-center"
            >
              Browse Available Properties
              <ArrowRight className="ml-2 w-5 h-5" />
            </button>
          </div>
        </div>
      </section>
    );
  };
}