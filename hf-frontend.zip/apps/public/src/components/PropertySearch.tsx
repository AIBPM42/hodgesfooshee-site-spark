import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
// UI components removed - using simple HTML elements instead
import { Search, MapPin, Bed, Bath, DollarSign, Home } from 'lucide-react';
// Hook removed - using simple state management instead
import ZipCodeAutocomplete from './ZipCodeAutocomplete';

const PropertySearch = () => {
  const navigate = useNavigate();
  // Static data for now, hook removed to fix build
  const cities = [];
  const [searchQuery, setSearchQuery] = useState('');
  const [propertyType, setPropertyType] = useState('all');
  const [city, setCity] = useState('all');
  const [beds, setBeds] = useState('any');
  const [baths, setBaths] = useState('any');
  const [priceRange, setPriceRange] = useState([100000, 1000000]);

  const propertyTypes = [
    'Single Family Residential',
    'Condominium',
    'Townhouse',
    'Multi-Family',
    'Land/Lots',
    'Commercial'
  ];

  const handleSearch = () => {
    const params = new URLSearchParams();
    
    if (searchQuery.trim()) params.set('q', searchQuery.trim());
    if (city && city !== 'all') params.set('city', city);
    if (propertyType && propertyType !== 'all') params.set('property_type', propertyType);
    if (beds && beds !== 'any') params.set('beds', beds);
    if (baths && baths !== 'any') params.set('baths', baths);
    if (priceRange[0] > 100000) params.set('minPrice', priceRange[0].toString());
    if (priceRange[1] < 1000000) params.set('maxPrice', priceRange[1].toString());
    // Set default page size for first load
    params.set('$top', '24');

    navigate(`/listings?${params.toString()}`);
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      handleSearch();
    }
  };

  return (
    <div className="w-full max-w-6xl mx-auto">
      {/* Main Search Bar */}
      <div className="bg-white/25 backdrop-blur-lg rounded-2xl border border-white/20 shadow-lg p-6" style={{boxShadow: 'var(--glass-shadow)'}}>
        
        {/* Search Input */}
        <div className="mb-6">
          <div className="relative">
            <Search className="absolute left-3 top-3 h-4 w-4 text-white/60" />
            <input
              placeholder="Search by address, neighborhood, MLS#..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              onKeyPress={handleKeyPress}
              className="w-full pl-10 bg-white/10 border border-white/30 text-white placeholder:text-white/60 h-12 text-lg backdrop-blur-sm rounded-md px-3"
            />
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4 items-end">
          {/* Property Type */}
          <div className="space-y-2">
            <label className="text-sm font-medium text-white/90 flex items-center">
              <Home className="w-4 h-4 mr-2" />
              Property Type
            </label>
            <select 
              value={propertyType} 
              onChange={(e) => setPropertyType(e.target.value)}
              className="w-full bg-white/20 border border-white/30 text-white backdrop-blur-sm hover:bg-white/30 transition-all rounded-md px-3 py-2"
            >
              <option value="all">All Types</option>
              {propertyTypes.map((type) => (
                <option key={type} value={type.toLowerCase()}>
                  {type}
                </option>
              ))}
            </select>
          </div>

          {/* Location */}
          <div className="space-y-2">
            <label className="text-sm font-medium text-white/90 flex items-center">
              <MapPin className="w-4 h-4 mr-2" />
              Location
            </label>
            <ZipCodeAutocomplete
              value={city === 'all' ? '' : city}
              onChange={(value) => setCity(value || 'all')}
              onKeyPress={handleKeyPress}
              placeholder="Enter city, zip code, or area"
              className="bg-white/20 border-white/30 text-white placeholder:text-white/60 backdrop-blur-sm hover:bg-white/30 transition-all"
            />
          </div>

          {/* Bedrooms */}
          <div className="space-y-2">
            <label className="text-sm font-medium text-white/90 flex items-center">
              <Bed className="w-4 h-4 mr-2" />
              Min Beds
            </label>
            <input
              type="number"
              placeholder="Any"
              value={beds === 'any' ? '' : beds}
              onChange={(e) => setBeds(e.target.value || 'any')}
              className="w-full bg-white/20 border border-white/30 text-white placeholder:text-white/60 backdrop-blur-sm hover:bg-white/30 transition-all rounded-md px-3 py-2"
              min="1"
              max="10"
            />
          </div>

          {/* Bathrooms */}
          <div className="space-y-2">
            <label className="text-sm font-medium text-white/90 flex items-center">
              <Bath className="w-4 h-4 mr-2" />
              Min Baths
            </label>
            <input
              type="number"
              placeholder="Any"
              value={baths === 'any' ? '' : baths}
              onChange={(e) => setBaths(e.target.value || 'any')}
              className="w-full bg-white/20 border border-white/30 text-white placeholder:text-white/60 backdrop-blur-sm hover:bg-white/30 transition-all rounded-md px-3 py-2"
              min="1"
              max="10"
              step="0.5"
            />
          </div>

          {/* Search Button */}
          <div className="space-y-2">
            <label className="text-sm font-medium text-transparent">Search</label>
            <button 
              onClick={handleSearch}
              className="w-full bg-accent hover:bg-accent/90 text-white font-semibold h-12 transition-all duration-300 hover:scale-105 shadow-lg rounded-md px-4 py-2"
              style={{
                background: 'hsl(var(--accent))',
                boxShadow: '0 4px 20px hsl(var(--accent) / 0.3)'
              }}
            >
              <Search className="w-4 h-4 mr-2 inline" />
              Search Properties
            </button>
          </div>
        </div>

        {/* Price Range Slider */}
        <div className="mt-6 pt-6 border-t border-white/20">
          <div className="flex items-center justify-between mb-4">
            <label className="text-sm font-medium text-white/90 flex items-center">
              <DollarSign className="w-4 h-4 mr-2" />
              Price Range
            </label>
            <div className="text-sm text-white/80">
              ${priceRange[0].toLocaleString()} - ${priceRange[1].toLocaleString()}
            </div>
          </div>
          <input
            type="range"
            min="50000"
            max="2000000"
            step="25000"
            value={priceRange[0]}
            onChange={(e) => setPriceRange([parseInt(e.target.value), priceRange[1]])}
            className="w-full"
          />
          <input
            type="range"
            min="50000"
            max="2000000"
            step="25000"
            value={priceRange[1]}
            onChange={(e) => setPriceRange([priceRange[0], parseInt(e.target.value)])}
            className="w-full"
          />
        </div>
      </div>
    </div>
  );
};

export default PropertySearch;