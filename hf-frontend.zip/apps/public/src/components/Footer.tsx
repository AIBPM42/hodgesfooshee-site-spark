import React from 'react';
import { MapPin, Phone, Mail, Home } from 'lucide-react';

const Footer = () => {
  const counties = [
    'Davidson County', 'Williamson County', 'Rutherford County',
    'Dickson County', 'Robertson County', 'Maury County',
    'Sumner County', 'Wilson County', 'Cheatham County'
  ];

  const quickLinks = [
    'Buy a Home',
    'Sell Your Home', 
    'Market Reports',
    'About Us',
    'Contact',
    'Blog'
  ];

  return (
    <footer className="relative bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 text-white">
      {/* Glassmorphism overlay */}
      <div className="absolute inset-0 bg-black/20 backdrop-blur-sm"></div>
      
      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          
          {/* Company Info */}
          <div className="lg:col-span-1">
            <div className="flex items-center mb-6">
              <Home className="w-8 h-8 text-orange-500 mr-3" />
              <h3 className="text-2xl font-bold">Hodges & Fooshee</h3>
            </div>
            <p className="text-gray-300 mb-6 leading-relaxed">
              Your trusted real estate experts serving the Middle Tennessee area with over 25 years of combined experience.
            </p>
            
            {/* Contact Info */}
            <div className="space-y-3">
              <div className="flex items-center">
                <MapPin className="w-5 h-5 text-orange-500 mr-3 flex-shrink-0" />
                <span className="text-gray-300">1404 17th Ave South  
Nashville, TN 37212</span>
              </div>
              <div className="flex items-center">
                <Phone className="w-5 h-5 text-orange-500 mr-3" />
                <span className="text-gray-300">615-538-1100</span>
              </div>
              <div className="flex items-center">
                <Mail className="w-5 h-5 text-orange-500 mr-3" />
                <span className="text-gray-300">officemanager@hf95.com</span>
              </div>
            </div>
          </div>

          {/* Quick Links */}
          <div className="lg:col-span-1">
            <h4 className="text-xl font-semibold mb-6 text-orange-500">Quick Links</h4>
            <ul className="space-y-3">
              {quickLinks.map((link, index) => (
                <li key={index}>
                  <a 
                    href="#" 
                    className="text-gray-300 hover:text-orange-400 transition-colors duration-200 hover:translate-x-1 transform inline-block"
                  >
                    {link}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Service Areas */}
          <div className="lg:col-span-2">
            <h4 className="text-xl font-semibold mb-6 text-orange-500">Middle Tennessee Service Areas</h4>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
              {counties.map((county, index) => (
                <div 
                  key={index}
                  className="bg-white/5 backdrop-blur-sm rounded-lg px-3 py-2 border border-white/10 hover:bg-white/10 transition-all duration-200 hover:scale-105"
                >
                  <span className="text-gray-300 text-sm font-medium">{county}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Bottom Section */}
        <div className="border-t border-white/10 mt-8 pt-4">
          <div className="flex flex-col md:flex-row justify-between items-center space-y-4 md:space-y-0">
            
            {/* Copyright */}
            <div className="text-gray-400 text-sm">
              © 2025 Hodges & Fooshee Realty. All rights reserved.
            </div>

            {/* Legal Links */}
            <div className="flex space-x-6 text-sm">
              <a href="#" className="text-gray-400 hover:text-orange-400 transition-colors">
                Privacy Policy
              </a>
              <a href="#" className="text-gray-400 hover:text-orange-400 transition-colors">
                Terms of Service
              </a>
              <a href="#" className="text-gray-400 hover:text-orange-400 transition-colors">
                Equal Housing Opportunity
              </a>
            </div>
          </div>

          {/* MLS Disclaimer */}
          <div className="mt-3 text-xs text-gray-500 text-center">
            <p>
              The data relating to real estate for sale on this website appears in part through the BRIGHT Internet Data Exchange program, 
              a voluntary cooperative exchange of property listing data between licensed real estate brokerage firms in which Hodges & Fooshee Realty participates, 
              and is provided by BRIGHT through a licensing agreement. The information provided by this website is for the personal, 
              non-commercial use of consumers and may not be used for any purpose other than to identify prospective properties consumers may be interested in purchasing.
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;