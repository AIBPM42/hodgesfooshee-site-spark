import { useState, useEffect } from 'react';
import { useSearchParams, useNavigate } from 'react-router-dom';
// Hook removed - using simple state management instead

export const SearchFilters = () => {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const cities = []; // Static for now, hook removed to fix build
  
  const [city, setCity] = useState(searchParams.get('city') || 'all');
  const [priceRange, setPriceRange] = useState([
    parseInt(searchParams.get('min_price') || '0'),
    parseInt(searchParams.get('max_price') || '2000000')
  ]);
  const [beds, setBeds] = useState(searchParams.get('beds') || 'any');
  const [baths, setBaths] = useState(searchParams.get('baths') || 'any');
  const [sortBy, setSortBy] = useState(searchParams.get('sort') || 'price_desc');

  // Update local state when URL params change
  useEffect(() => {
    setCity(searchParams.get('city') || 'all');
    setPriceRange([
      parseInt(searchParams.get('min_price') || '0'),
      parseInt(searchParams.get('max_price') || '2000000')
    ]);
    setBeds(searchParams.get('beds') || 'any');
    setBaths(searchParams.get('baths') || 'any');
    setSortBy(searchParams.get('sort') || 'price_desc');
  }, [searchParams]);

  const updateFilters = () => {
    const newParams = new URLSearchParams();
    
    // Keep existing search query
    const currentQuery = searchParams.get('q');
    if (currentQuery) newParams.set('q', currentQuery);
    
    // Add filter params
    if (city && city !== 'all') newParams.set('city', city);
    if (priceRange[0] > 0) newParams.set('min_price', priceRange[0].toString());
    if (priceRange[1] < 2000000) newParams.set('max_price', priceRange[1].toString());
    if (beds && beds !== 'any') newParams.set('beds', beds);
    if (baths && baths !== 'any') newParams.set('baths', baths);
    if (sortBy !== 'price_desc') newParams.set('sort', sortBy);
    
    // Reset to page 1
    newParams.set('page', '1');
    
    navigate(`/search?${newParams.toString()}`, { replace: true });
  };

  const clearFilters = () => {
    navigate('/search', { replace: true });
  };

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
      notation: price >= 1000000 ? 'compact' : 'standard'
    }).format(price);
  };

  return (
    <div className="bg-white/10 backdrop-blur-md rounded-lg border border-white/20 p-6 shadow-lg">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-6 gap-4 items-end">
        
        {/* City Filter */}
        <div className="space-y-2">
          <label className="text-sm font-medium text-white">City</label>
          <select 
            value={city} 
            onChange={(e) => setCity(e.target.value)}
            className="w-full px-3 py-2 bg-white/10 border border-white/20 rounded-md text-white"
          >
            <option value="all">All Cities</option>
            {cities?.map((cityOption) => (
              <option key={cityOption.slug} value={cityOption.slug} className="text-black">
                {cityOption.name}
              </option>
            ))}
          </select>
        </div>

        {/* Beds Filter */}
        <div className="space-y-2">
          <label className="text-sm font-medium text-white">Bedrooms</label>
          <select 
            value={beds} 
            onChange={(e) => setBeds(e.target.value)}
            className="w-full px-3 py-2 bg-white/10 border border-white/20 rounded-md text-white"
          >
            <option value="any">Any</option>
            <option value="1" className="text-black">1+</option>
            <option value="2" className="text-black">2+</option>
            <option value="3" className="text-black">3+</option>
            <option value="4" className="text-black">4+</option>
            <option value="5" className="text-black">5+</option>
          </select>
        </div>

        {/* Baths Filter */}
        <div className="space-y-2">
          <label className="text-sm font-medium text-white">Bathrooms</label>
          <select 
            value={baths} 
            onChange={(e) => setBaths(e.target.value)}
            className="w-full px-3 py-2 bg-white/10 border border-white/20 rounded-md text-white"
          >
            <option value="any">Any</option>
            <option value="1" className="text-black">1+</option>
            <option value="2" className="text-black">2+</option>
            <option value="3" className="text-black">3+</option>
            <option value="4" className="text-black">4+</option>
          </select>
        </div>

        {/* Sort Filter */}
        <div className="space-y-2">
          <label className="text-sm font-medium text-white">Sort By</label>
          <select 
            value={sortBy} 
            onChange={(e) => setSortBy(e.target.value)}
            className="w-full px-3 py-2 bg-white/10 border border-white/20 rounded-md text-white"
          >
            <option value="price_desc" className="text-black">Price: High to Low</option>
            <option value="price_asc" className="text-black">Price: Low to High</option>
            <option value="newest" className="text-black">Newest Listings</option>
            <option value="beds_desc" className="text-black">Most Bedrooms</option>
          </select>
        </div>

        {/* Action Buttons */}
        <div className="flex gap-2">
          <button 
            onClick={updateFilters} 
            className="flex-1 px-4 py-2 bg-orange-500 text-white rounded-md hover:bg-orange-600 transition-colors"
          >
            Apply Filters
          </button>
          <button 
            onClick={clearFilters} 
            className="px-4 py-2 border border-white/20 text-white rounded-md hover:bg-white/10 transition-colors"
          >
            Clear
          </button>
        </div>
      </div>

      {/* Price Range */}
      <div className="mt-6 space-y-3">
        <label className="text-sm font-medium text-white">Price Range</label>
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="text-xs text-gray-300">Min Price</label>
            <input
              type="range"
              min="0"
              max="2000000"
              step="25000"
              value={priceRange[0]}
              onChange={(e) => setPriceRange([parseInt(e.target.value), priceRange[1]])}
              className="w-full"
            />
            <span className="text-sm text-gray-300">{formatPrice(priceRange[0])}</span>
          </div>
          <div>
            <label className="text-xs text-gray-300">Max Price</label>
            <input
              type="range"
              min="0"
              max="2000000"
              step="25000"
              value={priceRange[1]}
              onChange={(e) => setPriceRange([priceRange[0], parseInt(e.target.value)])}
              className="w-full"
            />
            <span className="text-sm text-gray-300">{formatPrice(priceRange[1])}</span>
          </div>
        </div>
      </div>
    </div>
  );
};
