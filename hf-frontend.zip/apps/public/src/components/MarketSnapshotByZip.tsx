import React from 'react';
import { useNavigate } from 'react-router-dom';
import { TrendingUp, TrendingDown, Home, Clock, Star, MapPin } from 'lucide-react';
// Button removed - using simple HTML elements instead
// Hook removed - using simple state management instead

interface MarketSnapshotProps {
  dataMode?: 'static' | 'live';
}

const MarketSnapshotByZip: React.FC<MarketSnapshotProps> = ({ dataMode = 'live' }) => {
  const navigate = useNavigate();
  
  console.log('MarketSnapshotByZip component rendering');

  // Popular Nashville area zip codes for display
  const popularZipCodes = [
    '37215', // Green Hills/Belle Meade
    '37212', // Music Row/Gulch
    '37206', // East Nashville
    '37203', // The Nations/Sylvan Park
    '37205', // Belle Meade/West End
    '37208', // Germantown/Salemtown
  ];

  const handleZipSearch = (zipCode: string) => {
    navigate(`/listings?city=${zipCode}`);
  };

  return (
    <section className="py-16 bg-gradient-to-b from-background to-secondary/20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
            Nashville Market Intelligence by Zip Code
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Explore real-time market data across Nashville's most desirable neighborhoods. 
            Click any area to see available properties.
          </p>
        </div>

        {/* Zip Code Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-12">
          {popularZipCodes.map((zipCode) => (
            <ZipCodeCard 
              key={zipCode} 
              zipCode={zipCode} 
              onClick={() => handleZipSearch(zipCode)}
              dataMode={dataMode}
            />
          ))}
        </div>

        {/* CTA */}
        <div className="text-center">
          <button 
            onClick={() => navigate('/listings')} 
            className="bg-primary hover:bg-primary-light text-primary-foreground px-8 py-3 text-lg font-semibold rounded-md"
          >
            Explore All Areas
          </button>
        </div>
      </div>
    </section>
  );
};

interface ZipCodeCardProps {
  zipCode: string;
  onClick: () => void;
  dataMode?: 'static' | 'live';
}

const ZipCodeCard: React.FC<ZipCodeCardProps> = ({ zipCode, onClick, dataMode = 'live' }) => {
  // Only fetch data in live mode
  const { data: details, isLoading, error } = useZipCodeDetails(dataMode === 'live' ? zipCode : '');

  console.log(`ZipCode ${zipCode} - Loading: ${isLoading}, Data:`, details, 'Error:', error);

  // Fallback data for popular areas when API data isn't available
  const getAreaInfo = (zip: string) => {
    const areaMap: Record<string, { name: string; highlights: string }> = {
      '37215': { name: 'Green Hills', highlights: 'Upscale shopping, dining' },
      '37212': { name: 'Music Row', highlights: 'Downtown luxury, entertainment' },
      '37206': { name: 'East Nashville', highlights: 'Trendy, artsy, growing' },
      '37203': { name: 'The Nations', highlights: 'Family-friendly, accessible' },
      '37205': { name: 'Belle Meade', highlights: 'Historic luxury estates' },
      '37208': { name: 'Germantown', highlights: 'Historic charm, walkable' },
    };
    return areaMap[zip] || { name: 'Nashville Area', highlights: 'Great location' };
  };

  const areaInfo = getAreaInfo(zipCode);

  // In static mode, always show loading or fallback data
  if (dataMode === 'static' || isLoading) {
    return (
      <div className="bg-card border border-border rounded-lg p-6 animate-pulse">
        <div className="h-4 bg-muted rounded mb-2"></div>
        <div className="h-6 bg-muted rounded mb-4"></div>
        <div className="space-y-2">
          <div className="h-4 bg-muted rounded"></div>
          <div className="h-4 bg-muted rounded"></div>
        </div>
      </div>
    );
  }

  return (
    <div 
      className="group bg-card hover:bg-card/80 border border-border hover:border-primary/20 rounded-lg p-6 cursor-pointer transition-all duration-300 hover:shadow-lg hover:scale-105"
      onClick={onClick}
    >
      {/* Header */}
      <div className="flex items-center justify-between mb-4">
        <div>
          <div className="flex items-center">
            <MapPin className="w-4 h-4 text-primary mr-2" />
            <span className="text-sm font-medium text-muted-foreground">{zipCode}</span>
          </div>
          <h3 className="text-xl font-bold text-foreground group-hover:text-primary transition-colors">
            {areaInfo.name}
          </h3>
        </div>
        <Home className="w-6 h-6 text-primary/60 group-hover:text-primary transition-colors" />
      </div>

      {/* Market Data */}
      <div className="space-y-3">
        {details && dataMode === 'live' ? (
          <>
            <div className="flex items-center justify-between">
              <span className="text-sm text-muted-foreground">Median Price</span>
              <span className="font-semibold text-foreground">
                ${details.MedianPrice?.toLocaleString() || 'N/A'}
              </span>
            </div>
            
            <div className="flex items-center justify-between">
              <span className="text-sm text-muted-foreground">Avg. Days on Market</span>
              <div className="flex items-center">
                <Clock className="w-3 h-3 text-muted-foreground mr-1" />
                <span className="font-semibold text-foreground">
                  {details.DaysOnMarket || 'N/A'}
                </span>
              </div>
            </div>

            {details.PriceChange !== undefined && (
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">Price Trend</span>
                <div className="flex items-center">
                  {details.PriceChange > 0 ? (
                    <TrendingUp className="w-3 h-3 text-green-600 mr-1" />
                  ) : (
                    <TrendingDown className="w-3 h-3 text-red-600 mr-1" />
                  )}
                  <span className={`font-semibold ${details.PriceChange > 0 ? 'text-green-600' : 'text-red-600'}`}>
                    {details.PriceChange > 0 ? '+' : ''}{details.PriceChange}%
                  </span>
                </div>
              </div>
            )}

            <div className="flex items-center justify-between">
              <span className="text-sm text-muted-foreground">Active Listings</span>
              <span className="font-semibold text-foreground">
                {details.ActiveListings || 'N/A'}
              </span>
            </div>
          </>
        ) : (
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-sm text-muted-foreground">Market Tier</span>
              <div className="flex items-center">
                <Star className="w-3 h-3 text-yellow-500 mr-1" />
                <span className="font-semibold text-foreground">Premium</span>
              </div>
            </div>
            <div className="text-sm text-muted-foreground">
              {areaInfo.highlights}
            </div>
          </div>
        )}
      </div>

      {/* CTA */}
      <div className="mt-4 pt-4 border-t border-border/50">
        <button 
          className="w-full group-hover:bg-primary group-hover:text-primary-foreground transition-colors text-sm px-3 py-2 rounded-md bg-transparent hover:bg-accent"
        >
          View Properties in {areaInfo.name}
        </button>
      </div>
    </div>
  );
};

export default MarketSnapshotByZip;