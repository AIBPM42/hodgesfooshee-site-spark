import React from "react";
import { useLocation } from "react-router-dom";

// Public site doesn't render data-driven blocks on Home yet.
// Provide a no-op stub so Index.tsx compiles without fetching data.
type Block = { type: string; props?: Record<string, any> };

export default function BlockRenderer({ blocks = [] as Block[] }) {
  const location = useLocation();
  
  // Only skip data blocks on the home route
  if (location.pathname === '/') {
    // Optionally log once in dev to remind us to wire real blocks later.
    if (import.meta.env.DEV && blocks.length) {
      console.info("[BlockRenderer:public] skipping", blocks.length, "blocks on home route (premium hero handles the UI).");
    }
    return null; // Intentionally renders nothing on Home (premium hero handles the UI)
  }
  
  // For other routes, render blocks normally (when implemented)
  if (import.meta.env.DEV && blocks.length) {
    console.info("[BlockRenderer:public] rendering", blocks.length, "blocks (stubbed, no data fetch).");
  }
  return null; // Still stubbed for non-home routes, implement as needed
}