import React, { useState, useEffect } from 'react';
import { useSearchParams, useNavigate } from 'react-router-dom';
// Hooks removed - using simple state management instead

export const CityChips = () => {
  // Static data for now, hook removed to fix build
  const cities = [];
  const navigate = useNavigate();

  const handleCityClick = (citySlug: string) => {
    navigate(`/search?city=${encodeURIComponent(citySlug)}`);
  };

  if (!cities?.length) {
    return null;
  }

  // Show top 8 cities by sort_order
  const topCities = cities.slice(0, 8);

  return (
    <div className="w-full max-w-7xl mx-auto px-4 py-6">
      <div className="text-center mb-4">
        <h2 className="text-lg font-semibold text-foreground/90">Popular Areas</h2>
      </div>
      <div className="flex flex-wrap justify-center gap-3">
        {topCities.map((city) => (
          <button
            key={city.slug}
            className="px-4 py-2 text-sm font-medium bg-background/40 backdrop-blur-md border border-white/20 hover:bg-background/60 hover:border-white/30 cursor-pointer transition-all duration-300 hover:scale-105 rounded-md"
            onClick={() => handleCityClick(city.slug)}
          >
            {city.name}
          </button>
        ))}
      </div>
    </div>
  );
};