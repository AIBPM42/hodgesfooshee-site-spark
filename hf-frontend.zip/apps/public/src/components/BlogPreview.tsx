import React from 'react';
import { TrendingUp, Clock, ArrowRight, Calendar, User } from 'lucide-react';

const BlogPreview = () => {
  const blogPosts = [
    {
      id: 1,
      title: "Nashville Market Report: Q4 2024 Trends",
      excerpt: "Discover the latest market trends, price movements, and investment opportunities across Middle Tennessee's hottest neighborhoods.",
      category: "Market Reports",
      readTime: "5 min read",
      date: "Dec 15, 2024",
      author: "Hodges & Fooshee Team",
      image: "/lovable-uploads/market-trends.jpg",
      slug: "nashville-market-report-q4-2024"
    },
    {
      id: 2,
      title: "First-Time Buyer's Guide to Nashville",
      excerpt: "Everything you need to know about purchasing your first home in Nashville, from financing to neighborhood selection.",
      category: "Buyer Guides",
      readTime: "8 min read", 
      date: "Dec 12, 2024",
      author: "Hodges & Fooshee Team",
      image: "/lovable-uploads/first-time-buyer.jpg",
      slug: "first-time-buyers-guide-nashville"
    },
    {
      id: 3,
      title: "Investment Properties: East Nashville ROI Analysis",
      excerpt: "Deep dive into East Nashville's investment potential with real ROI data, rental yields, and future growth projections.",
      category: "Investment Insights",
      readTime: "6 min read",
      date: "Dec 10, 2024", 
      author: "Hodges & Fooshee Team",
      image: "/lovable-uploads/investment-analysis.jpg",
      slug: "east-nashville-investment-roi-analysis"
    }
  ];

  return (
    <section className="relative py-20 px-4 sm:px-6 lg:px-8 overflow-hidden" style={{background: 'linear-gradient(135deg, #2d2d2d 0%, #3d3d3d 30%, #4a4a4a 70%, #2d2d2d 100%)'}}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-16">
          <div className="flex items-center justify-center mb-4">
            <TrendingUp className="w-8 h-8 text-orange-500 mr-3" />
            <h2 className="text-4xl font-bold text-white">
              Latest Market <span className="text-orange-500">Insights</span>
            </h2>
          </div>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto">
            Stay ahead with expert analysis and insights from Nashville's most trusted real estate professionals
          </p>
        </div>

        {/* Blog Posts Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-12">
          {blogPosts.map((post) => (
            <article
              key={post.id}
              className="group bg-white/10 backdrop-blur-md rounded-2xl border border-white/20 overflow-hidden hover:bg-white/15 transition-all duration-300 hover:scale-105 hover:shadow-2xl"
            >
              {/* Post Image */}
              <div className="relative h-48 bg-gradient-to-br from-orange-500/20 to-orange-600/10 overflow-hidden">
                <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent" />
                <div className="absolute top-4 left-4">
                  <span className="px-3 py-1 bg-orange-500/90 text-white text-sm font-semibold rounded-full">
                    {post.category}
                  </span>
                </div>
                <div className="absolute bottom-4 left-4 right-4">
                  <div className="flex items-center text-white/80 text-sm space-x-4">
                    <div className="flex items-center">
                      <Calendar className="w-4 h-4 mr-1" />
                      {post.date}
                    </div>
                    <div className="flex items-center">
                      <Clock className="w-4 h-4 mr-1" />
                      {post.readTime}
                    </div>
                  </div>
                </div>
              </div>

              {/* Post Content */}
              <div className="p-6">
                <h3 className="text-xl font-bold text-white mb-3 group-hover:text-orange-300 transition-colors line-clamp-2">
                  {post.title}
                </h3>
                <p className="text-gray-300 mb-4 line-clamp-3">
                  {post.excerpt}
                </p>
                
                {/* Post Meta */}
                <div className="flex items-center justify-between">
                  <div className="flex items-center text-gray-400 text-sm">
                    <User className="w-4 h-4 mr-1" />
                    {post.author}
                  </div>
                  <a href="/blog" className="flex items-center text-orange-500 hover:text-orange-400 transition-colors font-semibold">
                    Read More
                    <ArrowRight className="w-4 h-4 ml-1 group-hover:translate-x-1 transition-transform" />
                  </a>
                </div>
              </div>
            </article>
          ))}
        </div>

        {/* Call to Action */}
        <div className="text-center">
          <a href="/blog" className="inline-flex items-center px-8 py-4 bg-gradient-to-r from-orange-500 to-orange-600 text-white font-bold rounded-xl hover:from-orange-600 hover:to-orange-700 transition-all duration-300 shadow-lg hover:shadow-xl transform hover:scale-105">
            <TrendingUp className="w-5 h-5 mr-2" />
            See All Market Insights
            <ArrowRight className="w-5 h-5 ml-2" />
          </a>
        </div>
      </div>
    </section>
  );
};

export default BlogPreview;
