import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { TrendingUp, DollarSign, MapPin, Calendar, Sparkles } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';

interface Opportunity {
  id: string;
  property_id: string;
  score: number;
  property: {
    address: string;
    city: string;
    price: number;
    beds: number;
    baths: number;
    sqft: number;
  };
  insights: {
    price_trend: 'dropping' | 'stable' | 'rising';
    days_on_market: number;
    predicted_sale_days: number;
    investment_rating: 'low' | 'medium' | 'high';
    reasons: string[];
  };
}

const AIOpportunityDashboard: React.FC = () => {
  const [opportunities, setOpportunities] = useState<Opportunity[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState<'all' | 'high' | 'medium' | 'low'>('all');
  const { toast } = useToast();

  // Mock data for demonstration - would be replaced with real Manus API calls
  useEffect(() => {
    const mockOpportunities: Opportunity[] = [
      {
        id: '1',
        property_id: 'MLS123456',
        score: 92,
        property: {
          address: '123 Music Row',
          city: 'Nashville',
          price: 450000,
          beds: 3,
          baths: 2,
          sqft: 1800
        },
        insights: {
          price_trend: 'dropping',
          days_on_market: 45,
          predicted_sale_days: 15,
          investment_rating: 'high',
          reasons: ['Price reduced 3 times', 'Below market value', 'Motivated seller', 'Great renovation potential']
        }
      },
      {
        id: '2',
        property_id: 'MLS789012',
        score: 78,
        property: {
          address: '456 Franklin Pike',
          city: 'Franklin',
          price: 325000,
          beds: 4,
          baths: 2.5,
          sqft: 2200
        },
        insights: {
          price_trend: 'stable',
          days_on_market: 25,
          predicted_sale_days: 30,
          investment_rating: 'medium',
          reasons: ['Competitive pricing', 'Good school district', 'Recent comps support value']
        }
      },
      {
        id: '3',
        property_id: 'MLS345678',
        score: 65,
        property: {
          address: '789 Belmont Blvd',
          city: 'Nashville',
          price: 280000,
          beds: 2,
          baths: 1,
          sqft: 1200
        },
        insights: {
          price_trend: 'rising',
          days_on_market: 12,
          predicted_sale_days: 45,
          investment_rating: 'low',
          reasons: ['New listing', 'Priced at market', 'Needs significant updates']
        }
      }
    ];

    setTimeout(() => {
      setOpportunities(mockOpportunities);
      setLoading(false);
    }, 1000);
  }, []);

  const getScoreColor = (score: number) => {
    if (score >= 80) return 'text-green-600 bg-green-100';
    if (score >= 60) return 'text-yellow-600 bg-yellow-100';
    return 'text-red-600 bg-red-100';
  };

  const getTrendIcon = (trend: string) => {
    switch (trend) {
      case 'dropping': return '📉';
      case 'rising': return '📈';
      default: return '➡️';
    }
  };

  const filteredOpportunities = opportunities.filter(opp => {
    if (filter === 'all') return true;
    return opp.insights.investment_rating === filter;
  });

  if (loading) {
    return (
      <div className="space-y-4">
        <div className="h-8 bg-muted rounded animate-pulse"></div>
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {[1, 2, 3].map(i => (
            <div key={i} className="h-64 bg-muted rounded animate-pulse"></div>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-bold">AI Opportunity Dashboard</h2>
          <p className="text-muted-foreground">AI-powered investment opportunities powered by Manus + OpenAI</p>
        </div>
        <Badge variant="outline" className="flex items-center gap-2">
          <Sparkles className="h-4 w-4" />
          Live AI Analysis
        </Badge>
      </div>

      <Tabs value={filter} onValueChange={(value) => setFilter(value as typeof filter)}>
        <TabsList>
          <TabsTrigger value="all">All Opportunities ({opportunities.length})</TabsTrigger>
          <TabsTrigger value="high">High Score ({opportunities.filter(o => o.insights.investment_rating === 'high').length})</TabsTrigger>
          <TabsTrigger value="medium">Medium Score ({opportunities.filter(o => o.insights.investment_rating === 'medium').length})</TabsTrigger>
          <TabsTrigger value="low">Low Score ({opportunities.filter(o => o.insights.investment_rating === 'low').length})</TabsTrigger>
        </TabsList>

        <TabsContent value={filter} className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {filteredOpportunities.map((opportunity) => (
              <Card key={opportunity.id} className="hover:shadow-lg transition-shadow">
                <CardHeader className="pb-4">
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-lg">{opportunity.property.address}</CardTitle>
                    <Badge className={getScoreColor(opportunity.score)}>
                      Score: {opportunity.score}
                    </Badge>
                  </div>
                  <div className="flex items-center gap-2 text-muted-foreground">
                    <MapPin className="h-4 w-4" />
                    <span>{opportunity.property.city}</span>
                  </div>
                </CardHeader>

                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div className="flex items-center gap-2">
                      <DollarSign className="h-4 w-4 text-green-600" />
                      <span>${opportunity.property.price.toLocaleString()}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Calendar className="h-4 w-4 text-blue-600" />
                      <span>{opportunity.insights.days_on_market} DOM</span>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 text-sm">
                    <span>{getTrendIcon(opportunity.insights.price_trend)}</span>
                    <span className="capitalize">{opportunity.insights.price_trend} trend</span>
                    <span className="text-muted-foreground">
                      • Est. {opportunity.insights.predicted_sale_days} days to sell
                    </span>
                  </div>

                  <div>
                    <p className="text-sm font-medium mb-2">AI Insights:</p>
                    <div className="space-y-1">
                      {opportunity.insights.reasons.slice(0, 3).map((reason, index) => (
                        <div key={index} className="text-xs bg-muted px-2 py-1 rounded">
                          {reason}
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="flex gap-2">
                    <Button size="sm" className="flex-1">
                      View Details
                    </Button>
                    <Button 
                      size="sm" 
                      variant="outline"
                      onClick={() => toast({
                        title: "AI Analysis",
                        description: `Generated detailed report for ${opportunity.property.address}`
                      })}
                    >
                      <TrendingUp className="h-4 w-4" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {filteredOpportunities.length === 0 && (
            <div className="text-center py-12">
              <p className="text-muted-foreground">No opportunities found for the selected filter.</p>
            </div>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default AIOpportunityDashboard;