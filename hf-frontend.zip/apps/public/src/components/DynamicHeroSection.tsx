import React from 'react';
// Button removed - using simple HTML elements instead
import PropertySearch from './PropertySearch';
import CountUpStat from './CountUpStat';
import { ArrowDown } from 'lucide-react';
import { Link } from 'react-router-dom';
import nashvilleHome from '../assets/nashville-luxury-home.jpg';

interface HeroPayload {
  headline?: string;
  subcopy?: string;
  cta?: {
    label: string;
    href: string;
  };
  bg?: {
    type: 'gradient' | 'image';
    from?: string;
    to?: string;
    image?: string;
  };
}

interface DynamicHeroSectionProps {
  payload: HeroPayload;
}

const DynamicHeroSection: React.FC<DynamicHeroSectionProps> = ({ payload }) => {
  const {
    headline = "Your Source for Nashville Real Estate Excellence",
    subcopy = "Discover exceptional properties across Middle Tennessee with Nashville's most trusted real estate experts"
  } = payload;

  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden pt-20">
      {/* Background Image with Overlay */}
      <div 
        className="absolute inset-0 bg-cover bg-center bg-no-repeat"
        style={{
          backgroundImage: `url(${nashvilleHome})`
        }}
      >
        {/* Warm Gradient Overlay */}
        <div className="absolute inset-0 bg-gradient-hero"></div>
      </div>

      {/* Content */}
      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        {/* Hero Text */}
        <div className="mb-12 animate-fade-in">
          <h1 className="text-4xl md:text-6xl font-extrabold text-white mb-4 leading-tight text-center px-5 md:px-0" style={{textShadow: '0 4px 12px rgba(0, 0, 0, 0.3)'}}>
            Your Source for{' '}
            <span 
              className="text-accent" 
              style={{
                opacity: '0.92',
                textShadow: '1px 2px 6px rgba(0, 0, 0, 0.4)',
                fontWeight: '750'
              }}
            >
              Nashville Real Estate
            </span>{' '}
            Excellence
          </h1>
          <p className="text-lg md:text-xl text-white/90 mb-10 font-normal max-w-2xl mx-auto text-center px-5 md:px-0" style={{textShadow: '0 2px 8px rgba(0, 0, 0, 0.2)'}}>
            {subcopy}
          </p>
        </div>

        {/* Property Search Component */}
        <div className="animate-fade-in animation-delay-300">
          <PropertySearch />
        </div>

        {/* Trust Indicators */}
        <div className="mt-10 md:mt-16 animate-fade-in animation-delay-600 mx-5 md:mx-0">
          <div 
            className="bg-white/25 backdrop-blur-lg border border-white/20 rounded-2xl p-5 md:px-10 md:py-6 flex flex-col md:flex-row justify-around items-center gap-5 md:gap-8 max-w-4xl mx-auto"
            style={{
              backdropFilter: 'blur(20px)',
              WebkitBackdropFilter: 'blur(20px)',
              boxShadow: 'var(--glass-shadow)'
            }}
          >
            <div className="text-center text-white">
              <div>
                <CountUpStat end={500} duration={2.5} suffix="+" delay={0} />
              </div>
              <div className="text-white/90 font-medium">Homes Sold</div>
            </div>
            <div className="text-center text-white">
              <div>
                <CountUpStat end={25} duration={2.0} suffix="+" delay={200} />
              </div>
              <div className="text-white/90 font-medium">Years Experience</div>
            </div>
            <div className="text-center text-white">
              <div>
                <CountUpStat end={9} duration={1.5} suffix="" delay={400} />
              </div>
              <div className="text-white/90 font-medium">Counties Served</div>
            </div>
            <div className="text-center text-white">
              <div>
                <CountUpStat end={98} duration={2.0} suffix="%" delay={600} />
              </div>
              <div className="text-white/90 font-medium">Client Satisfaction</div>
            </div>
          </div>
        </div>
      </div>

      {/* Scroll Indicator */}
      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 animate-bounce">
        <div className="w-6 h-10 border-2 border-white/40 rounded-full flex justify-center">
          <div className="w-1 h-3 bg-white/60 rounded-full mt-2 animate-pulse"></div>
        </div>
      </div>
    </section>
  );
};

export default DynamicHeroSection;