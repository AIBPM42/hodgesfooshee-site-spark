import React from 'react';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import {
  Carousel,
  CarouselContent,
  CarouselItem,
  CarouselNext,
  CarouselPrevious,
} from './ui/carousel';

const countyData = [
  {
    id: 1,
    name: "Davidson County",
    location: "Nashville",
    growth: "+4.2%",
    medianPrice: "$425,000",
    daysOnMarket: 18,
    priceTrend: "+8.1%",
    temperature: "HOT",
    tempIcon: "🔥",
    tempColor: "bg-red-500"
  },
  {
    id: 2,
    name: "Williamson County",
    location: "Franklin",
    growth: "+3.8%",
    medianPrice: "$650,000",
    daysOnMarket: 22,
    priceTrend: "+6.3%",
    temperature: "RISING",
    tempIcon: "📈",
    tempColor: "bg-orange-500"
  },
  {
    id: 3,
    name: "Rutherford County",
    location: "Murfreesboro",
    growth: "+2.1%",
    medianPrice: "$385,000",
    daysOnMarket: 25,
    priceTrend: "+3.2%",
    temperature: "STABLE",
    tempIcon: "📊",
    tempColor: "bg-blue-500"
  },
  {
    id: 4,
    name: "Sumner County",
    location: "Hendersonville",
    growth: "+3.2%",
    medianPrice: "$375,000",
    daysOnMarket: 28,
    priceTrend: "+4.8%",
    temperature: "RISING",
    tempIcon: "📈",
    tempColor: "bg-orange-500"
  },
  {
    id: 5,
    name: "Wilson County",
    location: "Lebanon",
    growth: "+1.8%",
    medianPrice: "$395,000",
    daysOnMarket: 24,
    priceTrend: "+2.9%",
    temperature: "STABLE",
    tempIcon: "📊",
    tempColor: "bg-blue-500"
  },
  {
    id: 6,
    name: "Cheatham County",
    location: "Cheatham County",
    growth: "+1.5%",
    medianPrice: "$325,000",
    daysOnMarket: 32,
    priceTrend: "+1.8%",
    temperature: "STABLE",
    tempIcon: "📊",
    tempColor: "bg-blue-500"
  },
  {
    id: 7,
    name: "Dickson County",
    location: "Dickson County",
    growth: "+2.8%",
    medianPrice: "$285,000",
    daysOnMarket: 35,
    priceTrend: "+5.2%",
    temperature: "RISING",
    tempIcon: "📈",
    tempColor: "bg-orange-500"
  },
  {
    id: 8,
    name: "Robertson County",
    location: "Robertson County",
    growth: "+1.9%",
    medianPrice: "$295,000",
    daysOnMarket: 30,
    priceTrend: "+2.1%",
    temperature: "STABLE",
    tempIcon: "📊",
    tempColor: "bg-blue-500"
  },
  {
    id: 9,
    name: "Maury County",
    location: "Columbia",
    growth: "+2.5%",
    medianPrice: "$315,000",
    daysOnMarket: 26,
    priceTrend: "+4.5%",
    temperature: "RISING",
    tempIcon: "📈",
    tempColor: "bg-orange-500"
  }
];


interface MarketIntelligenceProps {
  dataMode?: 'static' | 'live';
}

const MarketIntelligence: React.FC<MarketIntelligenceProps> = ({ dataMode = 'live' }) => {
  return (
    <section 
      className="relative py-20 px-4 sm:px-6 lg:px-8 overflow-hidden"
      style={{
        background: `linear-gradient(135deg, #2d2d2d 0%, #3d3d3d 30%, #4a4a4a 70%, #5a5a5a 100%)`
      }}
    >
      {/* Optional: Animated background particles */}
      <div className="absolute inset-0 opacity-10">
        <div className="absolute top-1/4 left-1/4 w-2 h-2 bg-white rounded-full animate-pulse"></div>
        <div className="absolute top-3/4 right-1/4 w-1 h-1 bg-white rounded-full animate-pulse" style={{animationDelay: '1s'}}></div>
        <div className="absolute top-1/2 left-3/4 w-1.5 h-1.5 bg-white rounded-full animate-pulse" style={{animationDelay: '2s'}}></div>
      </div>
      
      <div className="relative z-10 max-w-7xl mx-auto">
        {/* Section Header */}
        <div className="text-center mb-16 animate-fade-in">
          <h2 className="text-4xl md:text-5xl font-extrabold text-white mb-4">
            Middle Tennessee Market Intelligence
          </h2>
          <p className="text-xl md:text-2xl text-gray-300 mb-6 font-medium">
            Real-time insights across 9 counties from Nashville's most trusted experts
          </p>
          <p className="text-lg text-gray-400 max-w-3xl mx-auto">
            Our deep local knowledge combined with live market data gives you the intelligence edge
          </p>
        </div>

        {/* County Intelligence Carousel */}
        <div className="mb-12 animate-fade-in animation-delay-300">
          <Carousel
            opts={{
              align: "start",
              loop: true,
            }}
            className="w-full max-w-6xl mx-auto"
          >
            <CarouselContent className="-ml-2 md:-ml-4">
              {countyData.map((county) => (
                <CarouselItem key={county.id} className="pl-2 md:pl-4 md:basis-1/2 lg:basis-1/3">
                  <div className="p-1">
                     <div 
                      className="group relative overflow-hidden bg-white/10 backdrop-blur-md border border-white/20 rounded-2xl transition-all duration-300 hover:scale-105 hover:-translate-y-2 p-6 h-full shadow-2xl hover:shadow-3xl"
                    >
                      {/* County Header */}
                      <div className="flex justify-between items-start mb-4">
                        <div>
                          <h3 className="text-lg font-bold text-white">
                            {county.name}
                          </h3>
                          <p className="text-gray-300 text-sm">
                            {county.location}
                          </p>
                        </div>
                        <div className={`${county.tempColor} text-white px-3 py-1 rounded-xl text-xs font-semibold shadow-lg`}>
                          {county.tempIcon} {county.temperature}
                        </div>
                      </div>

                       {/* Population Growth */}
                      <div className="mb-4">
                        <p className="text-gray-300 text-xs mb-1">Population Growth</p>
                        <p className="text-green-400 font-semibold text-lg">
                          {county.growth}
                        </p>
                      </div>

                      {/* Median Price */}
                      <div className="mb-4">
                        <p className="text-gray-300 text-xs mb-1">Median Price</p>
                        <p className="text-2xl font-bold text-white">
                          {county.medianPrice}
                        </p>
                      </div>

                      {/* Days on Market */}
                      <div className="mb-4">
                        <p className="text-gray-300 text-xs mb-1">Days on Market</p>
                        <p className="text-white font-semibold text-lg">
                          {county.daysOnMarket} days
                        </p>
                      </div>

                      {/* Price Trend */}
                      <div className="mb-4">
                        <p className="text-gray-300 text-xs mb-1">Price Trend</p>
                        <p className="text-green-400 font-semibold text-lg flex items-center">
                          ↗ {county.priceTrend}
                        </p>
                      </div>

                      {/* View Details Button */}
                      <Button 
                        size="sm"
                        className="w-full bg-gradient-to-r from-[#FF4500] to-[#E55100] hover:from-[#E55100] hover:to-[#D84315] text-white font-semibold py-2 rounded-xl transition-all duration-300 hover:shadow-lg hover:shadow-orange-500/25"
                      >
                        View County Details
                      </Button>
                    </div>
                  </div>
                </CarouselItem>
              ))}
            </CarouselContent>
            <CarouselPrevious className="bg-white/10 backdrop-blur-md border border-white/20 text-white hover:bg-white/20 hover:scale-110 transition-all duration-300 shadow-2xl -left-12" />
            <CarouselNext className="bg-white/10 backdrop-blur-md border border-white/20 text-white hover:bg-white/20 hover:scale-110 transition-all duration-300 shadow-2xl -right-12" />
          </Carousel>
        </div>

        {/* Market Insights Panel */}
        <div className="mb-12 animate-fade-in animation-delay-600">
          <div 
            className="bg-white/10 backdrop-blur-md border border-white/20 rounded-2xl overflow-hidden p-8"
            style={{boxShadow: '0 35px 70px -12px rgba(0, 0, 0, 0.4)'}}
          >
            <h3 className="text-2xl font-bold text-white mb-6 text-center">
              Middle Tennessee Market Pulse
            </h3>
            
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6 text-center">
              <div>
                <div className="text-3xl font-bold text-green-400 mb-2">
                  STRONG
                </div>
                <div className="text-gray-300 text-sm">
                  Overall Market
                </div>
              </div>
              
              <div>
                <div className="text-3xl font-bold text-blue-400 mb-2">
                  1,247
                </div>
                <div className="text-gray-300 text-sm">
                  Investment Opportunities
                </div>
              </div>
              
              <div>
                <div className="text-3xl font-bold text-orange-400 mb-2">
                  18%
                </div>
                <div className="text-gray-300 text-sm">
                  New Construction
                </div>
              </div>
              
              <div>
                <div className="text-3xl font-bold text-purple-400 mb-2">
                  25
                </div>
                <div className="text-gray-300 text-sm">
                  Avg Days on Market
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Call-to-Action Buttons */}
        <div className="text-center flex flex-col sm:flex-row gap-4 justify-center animate-fade-in animation-delay-900">
          <Button 
            size="lg"
            className="bg-gradient-to-r from-[#FF4500] to-[#E55100] hover:from-[#E55100] hover:to-[#D84315] text-white font-bold py-4 px-8 rounded-2xl text-lg transition-all duration-300 hover:shadow-lg hover:shadow-orange-500/25"
          >
            Get Personalized Market Report
          </Button>
          <Button 
            size="lg"
            variant="outline"
            className="bg-white/10 backdrop-blur-md border-2 border-white/30 text-white font-semibold py-4 px-8 rounded-2xl text-lg hover:bg-white/20 transition-all duration-300"
          >
            Schedule Market Consultation
          </Button>
        </div>
      </div>
    </section>
  );
};

export default MarketIntelligence;