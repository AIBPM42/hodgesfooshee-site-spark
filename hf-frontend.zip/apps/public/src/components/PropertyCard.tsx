import React from "react";
import { Link } from "react-router-dom";

export type Property = {
  id?: string;
  ListingKey?: string | number;
  ListPrice?: number;
  PropertyType?: string;
  BedroomsTotal?: number;
  BathroomsTotalInteger?: number;
  LivingArea?: number;
  UnparsedAddress?: string;
  City?: string;
  StateOrProvince?: string;
  PostalCode?: string;
  Media?: { MediaURL?: string }[];
};

function fmtPrice(n?: number) {
  if (!n && n !== 0) return "—";
  try { return new Intl.NumberFormat("en-US", { style: "currency", currency: "USD", maximumFractionDigits: 0 }).format(n); }
  catch { return `$${n}`; }
}

export default function PropertyCard({ property }: { property: Property }) {
  const id = String(property?.ListingKey ?? property?.id ?? "");
  const img = property?.Media?.[0]?.MediaURL ?? "https://placehold.co/640x420/png";
  const price = fmtPrice(property?.ListPrice);
  const beds = property?.BedroomsTotal ?? "—";
  const baths = property?.BathroomsTotalInteger ?? "—";
  const sqft = property?.LivingArea ? `${property.LivingArea.toLocaleString()} sqft` : "—";
  const address = property?.UnparsedAddress ||
    [property?.City, property?.StateOrProvince, property?.PostalCode].filter(Boolean).join(", ");

  return (
    <article className="rounded-2xl overflow-hidden bg-white/5 border border-white/10">
      <img src={img} alt={address || "Property"} className="aspect-video w-full object-cover" loading="lazy" />
      <div className="p-4 space-y-1">
        <div className="text-lg font-semibold">{price}</div>
        <div className="text-sm opacity-80">{address || "Address unavailable"}</div>
        <div className="text-sm opacity-80">{beds} bd · {baths} ba · {sqft}</div>
        <div className="pt-2">
          <Link
            to={`/listings?listingKey=${encodeURIComponent(id)}`}
            className="inline-flex items-center rounded-xl px-3 py-2 bg-orange-500 text-white hover:bg-orange-600"
          >
            View details
          </Link>
        </div>
      </div>
    </article>
  );
}